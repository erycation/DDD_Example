import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { ToastService } from '../../services/cdm-portal/notification/toast.service';
import { catchError, finalize, throwError } from 'rxjs';
import { LoadingSpinnerService } from '../../services/cdm-portal/loading-spinner/loading-spinner.service';

let totalRequests = 0;

export const ErrorHandlingInterceptor: HttpInterceptorFn = (request, next) => {

  const loadingSpinnerService = inject(LoadingSpinnerService);
  const toastService = inject(ToastService);

  totalRequests++;
  loadingSpinnerService.setLoading(true);

  // Clone the request and add the authorization header
  const authenticateRequest = request.clone({
    setHeaders: {
      //Authorization: `Bearer ${authToken}` ToDo : Get Token from KONG
    }
  });
  
 // Pass the cloned request with the updated header to the next handler
  return next(authenticateRequest).pipe(
    
    catchError((errorResponse: any) => {      
      if (errorResponse instanceof HttpErrorResponse) {   
          toastService.error(`${errorResponse.error.message}`);
      }
      else{
         toastService.error(`${errorResponse.error}`);
      }
      return throwError(null);
    }),
    finalize(() => {
        totalRequests--;
        if (totalRequests == 0) {
           loadingSpinnerService.setLoading(false);
        }
      })
  );
};