import { Component, inject } from "@angular/core";
import { MatButtonModule } from "@angular/material/button";
import { MatDividerModule } from "@angular/material/divider";
import { MatIconModule } from "@angular/material/icon";
import { MatMenuModule } from "@angular/material/menu";
import { MatToolbarModule } from "@angular/material/toolbar";
import { RouterLink } from "@angular/router";
import { CommonModule } from "@angular/common";

@Component({
  selector: 'tih-header',
  standalone: true,
  imports: [
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatMenuModule,
    RouterLink,
    MatDividerModule,
    CommonModule
  ],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class TIHHeaderComponent {

    menuRoutes = [
    {
      path: "/systems",
      icon: "apps",
      label: "Systems",
    },
    {
      path: "/roles",
      icon: "business_center",
      label: "Roles",
    },
    {
      path: "/settings/system-roles",
      icon: "badge",
      label: "System Roles",
    },
    {
      path: "/settings/permissions",
      icon: "checklist_rtl",
      label: "Permissions",
    },
        {
      path: "settings/role-permissions",
      icon: "assignment_ind",
      label: "Role Permissions",
    },
    {
      path: "/settings/user-statuses",
      icon: "how_to_reg",
      label: "User Statuses",
    },
    {
      path: "/settings/actions-performed",
      icon: "rule_settings",
      label: "Actions Performed",
    },
    {
      path: "/settings/user-roles",
      icon: "supervised_user_circle",
      label: "User Roles",
    },
    {
      path: "/settings/audit-trail",
      icon: "history",
      label: "Audit Trail",
    },
  ];
}
