import { Component } from '@angular/core';
import { TIHHeaderComponent } from './header/header.component';
import { TIHFooterComponent } from './footer/footer.component';
import { SideMenuComponent } from '../../components/side-menu/side-menu.component';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-secured-layout',
  standalone: true,
  imports: [
    TIHHeaderComponent, 
    TIHFooterComponent,
    SideMenuComponent,
    MatIconModule
  ],
  templateUrl: './secured-layout.component.html',
  styleUrl: './secured-layout.component.scss'
})
export class SecuredLayoutComponent {
  isSidebarOpen = false;
  toggleSidebar() {
  this.isSidebarOpen = !this.isSidebarOpen;
  }
}
