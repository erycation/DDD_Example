import { Component } from '@angular/core';

@Component({
  selector: 'app-public-layout',
  standalone: true,
  imports: [],
  templateUrl: './public-layout.component.html',
  styleUrl: './public-layout.component.scss'
})
export class PublicLayoutComponent {

}
