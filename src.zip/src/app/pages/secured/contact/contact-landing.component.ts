import { Component, inject } from "@angular/core";
import { TabNavComponent } from "../../components/tab-nav/tab-nav.component";
import { Router, RouterModule } from "@angular/router";
import { BreadcrumbComponent } from "../../components/breadcrumbs/breadcrumb.component";
import { CommonModule } from "@angular/common";

@Component({
 selector: 'app-contact-landing',
  standalone: true,
  imports: [TabNavComponent, RouterModule, BreadcrumbComponent, CommonModule],
  templateUrl: './contact-landing.component.html',
  styleUrl: './contact-landing.component.scss'
})

export class ContactLandingComponent {
    contactTabs = [
    { label: 'Contacts', route: './' },
    { label: 'Trace', route: 'trace' },
    { label: 'Upload Contacts', route: 'upload' }
    ];

    private router = inject(Router)

  showTabs(): boolean {
    return !this.router.url.includes('/details/');
  }
}