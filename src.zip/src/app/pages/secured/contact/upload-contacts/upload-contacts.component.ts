import { Component, inject, TemplateRef, ViewChild } from "@angular/core";
import { TableConfig } from "../../../components/data-table/data-table.types";
import { DataTableComponent } from "../../../components/data-table/data-table.component";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { TihGenericDatepickerComponent } from "../../../components/tih-generic-datepicker/tih-generic-datepicker.component";
import { TihGenericButtonComponent } from "../../../components/tih-generic-button/tih-generic-button.component";

@Component({
 selector: 'app-upload-contacts',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    DataTableComponent,
    TihGenericDatepickerComponent,
    TihGenericButtonComponent
  ],
  templateUrl: './upload-contacts.component.html',
  styleUrl: './upload-contacts.component.scss'
})

export class UploadContactsComponent {
  fileContactsFormGroup!: FormGroup;
  private formBuilder = inject(FormBuilder);
  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;
  
 fileContactsDto: [] = [];
 
 fileContactsTableConfig: TableConfig = {
          columns: [
            { field: 'campaignName', header: 'Campaign Name', sortable: true },
            { field: 'vdn', header: 'Vdn', sortable: true },
            { field: '', header: 'Inserted Into Contact Uploader', sortable: true },
            { field: '', header: 'Deduped Contact Uploader' },
            { field: '', header: 'Inserted Into Olympus' },
            { field: '', header: 'Deduped Olympus' },
            { field: '', header: 'Status' },
            { field: '', header: 'Batch Name' },
            { field: '', header: 'Date Created' }
          ],
          actionsTemplate: this.actionsTemplate,
          enableSearch: true,
        }

  ngOnInit(): void {
    this.fileContactsFormGroup = this.formBuilder.group({
      fileContactsId: ['', Validators.required],
      startDate: [null],
      endDate: [null]
    });
  }
  

  onSearch() {
    if (this.fileContactsFormGroup.valid) {
      //to be implemented
    }
  }

  openFileContacts(fileContactsDto: any) {
    //to be implemented
  }
}
