import { Component, inject, OnInit, TemplateRef, ViewChild } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { ActivatedRoute, RouterModule } from "@angular/router";
import { BreadcrumbComponent } from "../../../../../components/breadcrumbs/breadcrumb.component";
import { TabNavComponent } from "../../../../../components/tab-nav/tab-nav.component";
import { TihGenericButtonComponent } from "../../../../../components/tih-generic-button/tih-generic-button.component";
import { ContactDto } from "../../../../../../models/contact-crud/contact/contact-dto";
import { TihGenericInputComponent } from "../../../../../components/tih-generic-input/tih-generic-input.component";
import { TihGenericDropdownComponent } from "../../../../../components/tih-generic-dropdown/tih-generic-dropdown.component";
import { ContactService } from "../../../../../../services/contact/contact/contact.service";
import { ContactQueryFilterDto } from "../../../../../../models/contact-crud/contact/contact-query-dto";
import { UpdateContactDto } from "../../../../../../models/contact-crud/contact/update-contact-dto";
import { UpdateContactRequestDto } from "../../../../../../models/contact-crud/contact/update-contact-request-dto";
import { ToastService } from "../../../../../../services/cdm-portal/notification/toast.service";
import { CommonModule } from "@angular/common";

@Component({
 selector: 'app-personal',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    BreadcrumbComponent,
    CommonModule,
    TabNavComponent,
    TihGenericInputComponent,
    TihGenericDropdownComponent,
    RouterModule,
    TihGenericButtonComponent
  ],
  templateUrl: './personal-details.component.html',
  styleUrl: './personal-details.component.scss'
})

export class PersonalDetailsComponent implements OnInit{
  personalDetailsFormGroup!: FormGroup;
  contactDto!: ContactDto;
  updateContactDto!: UpdateContactDto;
  genderOptions = [
      { label: 'Male', value: "Male" },
      { label: 'Female', value: "Female" },
      { label: 'Other', value: "Other" }
  ];

  private formBuilder = inject(FormBuilder);
  private contactService = inject(ContactService);
  private toast = inject(ToastService);
  private route = inject(ActivatedRoute);


  ngOnInit(): void {
      const longContactId = this.route.parent?.snapshot.params['longContactId'];
      const contactQueryDto: ContactQueryFilterDto = { longContactId: longContactId }
      this.contactService.getContactByQuery(contactQueryDto).subscribe(contactResponse => {
        this.contactDto = contactResponse[0]
      this.populateFormGroup(this.contactDto)
      })
  }

  populateFormGroup(contactDto: ContactDto) {
    this.personalDetailsFormGroup = this.formBuilder.group({
      title: new FormControl(contactDto.title),
      initials: new FormControl(contactDto.initials),
      firstName: new FormControl(contactDto.firstName),
      surname: new FormControl(contactDto.surname),
      cellNumber: new FormControl(contactDto.cellNumber, Validators.required),
      workTelNumber: new FormControl(contactDto.workTelNumber),
      email: new FormControl(contactDto.email),
      telNumber: new FormControl(contactDto.telNumber),
      idNumber: new FormControl(contactDto.idNumber),
      gender: new FormControl(contactDto.gender),
      dateOfBirth: new FormControl(contactDto.dateOfBirth),
      maritalStatus: new FormControl(contactDto.maritalStatus)
    })
  }

  onSave() {
    this.updateContactDto = {
      title: this.personalDetailsFormGroup.get('title')?.value,
      initials: this.personalDetailsFormGroup.get('initials')?.value,
      firstName: this.personalDetailsFormGroup.get('firstName')?.value,
      surname: this.personalDetailsFormGroup.get('surname')?.value,
      cellNumber: this.personalDetailsFormGroup.get('cellNumber')?.value,
      workTelNumber: this.personalDetailsFormGroup.get('workTelNumber')?.value,
      email: this.personalDetailsFormGroup.get('email')?.value,
      telNumber: this.personalDetailsFormGroup.get('telNumber')?.value,
      idNumber: this.personalDetailsFormGroup.get('idNumber')?.value,
      gender: this.personalDetailsFormGroup.get('gender')?.value,
      dateOfBirth: this.personalDetailsFormGroup.get('dateOfBirth')?.value,
      maritalStatus: this.personalDetailsFormGroup.get('maritalStatus')?.value,
    };

    const requestData: UpdateContactRequestDto = {
      contactId: this.contactDto.contactId,
      longContactId: this.contactDto.longContactId
    }

    this.contactService.updateContact(this.updateContactDto, requestData)
    .subscribe(updateResult =>
      {
        this.toast.success(updateResult.message);
      }
    ) 
  }
}