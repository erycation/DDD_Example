import { Component, inject, TemplateRef, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from "@angular/forms";
import { RouterModule } from "@angular/router";
import { BreadcrumbComponent } from "../../../../../components/breadcrumbs/breadcrumb.component";
import { TabNavComponent } from "../../../../../components/tab-nav/tab-nav.component";
import { TihGenericButtonComponent } from "../../../../../components/tih-generic-button/tih-generic-button.component";

@Component({
 selector: 'app-note',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    BreadcrumbComponent,
    TabNavComponent,
    RouterModule,
    TihGenericButtonComponent
  ],
  templateUrl: './notes.component.html',
  styleUrl: './notes.component.scss'
})

export class NotesComponent {
  notesFormGroup!: FormGroup;
  
  private formBuilder = inject(FormBuilder);

  ngOnInit(): void {
    this.notesFormGroup = this.formBuilder.group({
      comments: [''],
      earlierComments: ['']
    });
  }

  onSave() {
  }
}