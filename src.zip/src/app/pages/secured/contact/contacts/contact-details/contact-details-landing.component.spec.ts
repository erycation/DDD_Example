import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContactDetailsLandingComponent } from './contact-details-landing.component';

describe('ContactDetailsLandingComponent', () => {
  let component: ContactDetailsLandingComponent;
  let fixture: ComponentFixture<ContactDetailsLandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContactDetailsLandingComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContactDetailsLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
