import { Component, inject } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { TihGenericButtonComponent } from "../../../../components/tih-generic-button/tih-generic-button.component";
import { BreadcrumbComponent } from "../../../../components/breadcrumbs/breadcrumb.component";
import { TabNavComponent } from "../../../../components/tab-nav/tab-nav.component";
import { ActivatedRoute, RouterModule } from "@angular/router";

@Component({
 selector: 'app-contact',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    BreadcrumbComponent,
    TabNavComponent,
    RouterModule,
    TihGenericButtonComponent
  ],
  templateUrl: './contact-details-landing.component.html',
  styleUrl: './contact-details-landing.component.scss'
})

export class ContactDetailsLandingComponent {
  stepTabs = [
    { label: 'Contact Info', route: './' },
    { label: 'Personal Details', route: 'personal-details' },
    { label: 'System Info', route: 'system-info' },
    { label: 'Trace', route: 'trace' },
    { label: 'Notes', route: 'notes' }
  ];
}