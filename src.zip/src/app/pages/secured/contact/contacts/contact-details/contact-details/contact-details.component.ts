import { Component, inject, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { ActivatedRoute, RouterModule } from "@angular/router";
import { ContactDto } from "../../../../../../models/contact-crud/contact/contact-dto";
import { ContactQueryFilterDto } from "../../../../../../models/contact-crud/contact/contact-query-dto";
import { ContactService } from "../../../../../../services/contact/contact/contact.service";
import { CommonModule } from "@angular/common";

@Component({
 selector: 'app-contact',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    CommonModule,
    FormsModule,
    RouterModule
  ],
  templateUrl: './contact-details.component.html',
  styleUrl: './contact-details.component.scss'
})

export class ContactDetailsComponent implements OnInit {
  contactDetailsFormGroup!: FormGroup;
  contactDto!: ContactDto;
  
  private formBuilder = inject(FormBuilder);
  private contactService = inject(ContactService);
  private route = inject(ActivatedRoute);

    ngOnInit(): void {
      const longContactId = this.route.parent?.snapshot.params['longContactId'];
      const contactQueryDto: ContactQueryFilterDto = { longContactId: longContactId }
      this.contactService.getContactByQuery(contactQueryDto).subscribe(contactResponse => {
        this.contactDto = contactResponse[0]
        this.populateFormGroup(this.contactDto)
      })
    }
  

    populateFormGroup(contactDto: ContactDto | undefined): void {
      if (contactDto) {
        this.contactDetailsFormGroup = this.formBuilder?.group({
          vdn: new FormControl(contactDto.vdn),
          brokerCode: new FormControl(contactDto.brokerCode),
          cellNumber: new FormControl(contactDto.cellNumber, Validators.required),
          longContactId: new FormControl(contactDto.longContactId),
          contactId: new FormControl(contactDto.contactId),
          contactSource: new FormControl(contactDto.contactSource),
          leadNumber: new FormControl(contactDto.leadNumber),
          leadStatus: new FormControl(contactDto.leadStatus),
          policyNumber: new FormControl(contactDto.leadStatus),
          dedupeStatus: new FormControl(contactDto.dedupeStatus),
          contactStatus: new FormControl(contactDto.contactStatus)
        })
      };
    }
}