import { Component, inject, OnInit } from "@angular/core";
import { TraceDto } from "../../../../../../models/contact-crud/trace/trace-dto";
import { TraceService } from "../../../../../../services/contact/trace/trace.service";
import { TraceQueryFilterDto } from "../../../../../../models/contact-crud/trace/trace-query-dto";
import { ActivatedRoute } from "@angular/router";
import { TableConfig } from "../../../../../components/data-table/data-table.types";
import { DataTableComponent } from "../../../../../components/data-table/data-table.component";
import { CommonModule } from "@angular/common";

@Component({
  selector: 'app-contact-trace',
  standalone: true,
  imports: [CommonModule, DataTableComponent],
  templateUrl: './trace.component.html',
  styleUrl: './trace.component.scss'
})
export class TraceComponent implements OnInit {

  private traceService = inject(TraceService);
  private route = inject(ActivatedRoute);
  traceDto: TraceDto[] = [];

  traceTableConfig: TableConfig = {
    columns: [
      { field: 'changedBy', header: 'User' },
      { field: 'info', header: 'Info' },
      { field: 'comments', header: 'Comment' },
      { field: 'dateCreated', header: 'Date', sortable: true }
    ]
  };

  ngOnInit(): void {
    const longContactId = this.route.parent?.snapshot.params['longContactId'];
    if (longContactId) {
      const traceRequestData: TraceQueryFilterDto = { longContactId };
      this.traceService.getTraceByQuery(traceRequestData).subscribe(traceQueryResult => {
        this.traceDto = traceQueryResult;
      });
    }
  }
}