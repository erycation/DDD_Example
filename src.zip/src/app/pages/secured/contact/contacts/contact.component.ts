import { Component, inject, TemplateRef, ViewChild } from "@angular/core";
import { TableConfig } from "../../../components/data-table/data-table.types";
import { DataTableComponent } from "../../../components/data-table/data-table.component";
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from "@angular/forms";
import { TihGenericDatepickerComponent } from "../../../components/tih-generic-datepicker/tih-generic-datepicker.component";
import { TihGenericButtonComponent } from "../../../components/tih-generic-button/tih-generic-button.component";
import { ContactQueryFilterLimitDto } from "../../../../models/contact-crud/contact/contact-query-limit-dto";
import { ContactService } from "../../../../services/contact/contact/contact.service";
import { ContactDto } from "../../../../models/contact-crud/contact/contact-dto";
import { ActivatedRoute, Router, RouterModule } from "@angular/router";
import { TihGenericInputComponent } from "../../../components/tih-generic-input/tih-generic-input.component";
import { CommonModule } from "@angular/common";
import { MatIcon } from "@angular/material/icon";
import { ContactQueryFilterDto } from "../../../../models/contact-crud/contact/contact-query-dto";

@Component({
 selector: 'app-contact',
  standalone: true,
  imports: [
    ReactiveFormsModule,
    RouterModule,
    CommonModule,
    FormsModule,
    DataTableComponent,
    TihGenericInputComponent,
    TihGenericDatepickerComponent,
    TihGenericButtonComponent
  ],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss'
})

export class ContactComponent {
  contactFormGroup!: FormGroup;
  contactSearchFormGroup!: FormGroup;
  private contactService = inject(ContactService);
  private formBuilder = inject(FormBuilder);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;
  
 contactDto: ContactDto[] = [];
 contactTableConfig!: TableConfig;

 ngAfterViewInit(): void{
    setTimeout(() => {
      this.contactTableConfig = {
          columns: [
            { field: 'contactId', header: 'Contact ID', sortable: true },
            { field: 'vdn', header: 'Vdn', sortable: true },
            { field: 'contactSource', header: 'Contact Source', sortable: true },
            { field: 'cellNumber', header: 'Cell Number' },
            { field: 'client', header: 'Client (FL)' },
            { field: 'dedupeStatus', header: 'Dedupe Status' }
          ],
          actionsTemplate: this.actionsTemplate,
          enableSearch: true,
        }
    });
  }
  ngOnInit(): void {
    this.contactFormGroup = this.formBuilder.group({
      startDate: [null],
      endDate: [null],
      contactId: [null],
      cellNumber: [null],
      email: [null],
    });
  }


  onSearch() {
    if (this.contactFormGroup.valid) {
      
       const cellNumber = this.contactFormGroup.get("cellNumber")?.value;
       const contactId = this.contactFormGroup.get("contactId")?.value;
       const email = this.contactFormGroup.get("email")?.value;

       if(email || contactId || email){
        var contactQueryRequestData: ContactQueryFilterDto = {
          cellNumber: cellNumber,
          contactId: contactId,
          email: email,
        };
        this.contactService.getContactByQuery(contactQueryRequestData)
          .subscribe(contactQueryResult => { 
            this.contactDto = contactQueryResult
          })
       } else {
          var contactQueryLimitRequestData: ContactQueryFilterLimitDto = {
            startDate: this.contactFormGroup.get("startDate")?.value,
            endDate: this.contactFormGroup.get("endDate")?.value
          };
          this.contactService.getContactByQueryLimit(contactQueryLimitRequestData)
            .subscribe(contactQueryResult => { 
              this.contactDto = contactQueryResult
            })
       }
    }
  }

  openContact(contactDto: ContactDto) {
    this.router.navigate(['details', contactDto.longContactId], { relativeTo: this.route });
  }
}