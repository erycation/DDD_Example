import { Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { SmsLookupDto } from '../../../models/settings-crud/sms-lookups/sms-lookup-dto';
import { CompanyDto } from '../../../models/settings-crud/companies/company-dto';
import { SmsLookupService } from '../../../services/settings-crud/sms-lookup/sms-lookup.service';
import { CompanyService } from '../../../services/settings-crud/company/company.service';
import { CommonModule } from '@angular/common';
import { DataTableComponent } from '../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../components/tih-generic-button/tih-generic-button.component';
import { TableConfig } from '../../components/data-table/data-table.types';
import { SmsLookupUpdateDto } from '../../../models/settings-crud/sms-lookups/sms-lookup-update-dto';
import { ToastService } from '../../../services/cdm-portal/notification/toast.service';
import { LookupService } from '../../../services/settings-crud/lookups/lookups.service';
import { LookupDto } from '../../../models/settings-crud/lookups/lookup-dto';
import { AddSmsLookupComponent } from './add-sms-lookup/add-sms-lookup.component';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
import { MatDialog } from '@angular/material/dialog';
import { UpdateData } from '../../../models/cdm-portal/utilities/updateData';
import { UpdateSmsLookupComponent } from './update-sms-lookup/update-sms-lookup.component';

@Component({
  selector: 'app-sms-lookup',
  standalone: true,
  imports: [ CommonModule,DataTableComponent,TihGenericButtonComponent],
  templateUrl: './sms-lookup.component.html',
  styleUrl: './sms-lookup.component.scss'
})
export class SmsLookupComponent {

  smsLookupsDto: SmsLookupDto[] = [];
  smsLookupTableConfig!: TableConfig;
  companies: CompanyDto[] = [];
  lookups: LookupDto[] = [];

   @ViewChild('actions') actionsTemplate!: TemplateRef<any>;
  
    private smsLookupService = inject(SmsLookupService);
    private companyService = inject(CompanyService);
    private lookupService = inject(LookupService);
    private toastService = inject(ToastService);
    private dialog = inject(MatDialog);
  
  ngAfterViewInit(): void {
    setTimeout(() => {
      this.smsLookupTableConfig = {
        columns: [
          { field: 'englishMessage', header: 'English Message', sortable: true },
          { field: 'afrikaansMessage', header: 'Afrikaans Message', sortable: true },
          { field: 'typeName', header: 'Sms Type', sortable: true },
          { field: 'companyName', header: 'Company', sortable: true},
          { field: 'isActive', header: 'Enabled' }
        ],
        actionsTemplate: this.actionsTemplate,
        enableSearch: true,
        enableFilters: true,
        toggleFields: ['isActive'],
        onToggleChange: (updateRow) => this.toggleSmsLookupStatus(updateRow)
      };
    });
  }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.lookupService.getLookups().subscribe(lookupResponse => {
      this.lookups = lookupResponse;

      this.companyService.getCompanies().subscribe(companiesResponse => {
        this.companies = companiesResponse;

        this.smsLookupService.getSmsLookups().subscribe(smsLookupResponse => {
          this.smsLookupsDto = smsLookupResponse.map(sms => ({
            ...sms,
            companyName: this.getCompanyNameById(sms.companyId),
            typeName: this.getTypeNameById(sms.typeId)
          }));
        });
      });
    });
  }

  toggleSmsLookupStatus(smsLookupDto: SmsLookupDto): void {
    const smsLookupUpdateDto: SmsLookupUpdateDto = { isActive: smsLookupDto.isActive };

    this.smsLookupService
      .updateSmsLookup(smsLookupDto.id!, smsLookupUpdateDto)
      .subscribe(updateResponse => {
        if (updateResponse) {
          this.toastService.success(`${updateResponse.message}`);
        }
      });
  }

  addSmsLookup(): void {
    const dialogRef = this.dialog.open(AddSmsLookupComponent, {
      width: '800px',
      maxWidth: '1200px',
      data: {
        title: 'Add SMS Lookup'
      },
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((addSmsLookupResult: ResponseApi<SmsLookupDto>) => {
      if (addSmsLookupResult && addSmsLookupResult.data) {
        const newSmsLookup = {
          ...addSmsLookupResult.data,
          companyName: this.getCompanyNameById(addSmsLookupResult.data.companyId),
          typeName: this.getTypeNameById(addSmsLookupResult.data.typeId)
        };
        this.smsLookupsDto.push(newSmsLookup);
        this.toastService.success(addSmsLookupResult.message);
      }
    });
  }

  editSmsLookup(smsLookupDto: SmsLookupDto): void {
    const smsLookupUpdateData: UpdateData<SmsLookupDto> = {
      title: `Update ${smsLookupDto.title}`,
      message: '',
      modelDto: smsLookupDto
    };
    const dialogRef = this.dialog.open(UpdateSmsLookupComponent, {
      maxWidth: '1200px',
      data: smsLookupUpdateData,
      disableClose: true
    });
    dialogRef.afterClosed().subscribe((result: ResponseApi<SmsLookupDto>) => {
      if (result && result.data) {
        const index = this.smsLookupsDto.findIndex(x => x.id === result.data.id);
        this.smsLookupsDto[index] = {
          ...result.data,
          companyName: this.getCompanyNameById(result.data.companyId),
          typeName: this.getTypeNameById(result.data.typeId)
        };
        this.toastService.success(result.message);
      }
    });
  }

  getCompanyNameById(companyId?: number): string {
      return this.companies.find(c => c.id === companyId)?.name ?? 'Unknown';
  }

  getTypeNameById(typeId?: number): string {
      return this.lookups.find(t => t.id === typeId)?.name ?? '';
  }
}