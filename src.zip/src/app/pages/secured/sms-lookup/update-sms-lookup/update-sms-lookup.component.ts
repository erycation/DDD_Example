import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { SmsLookupService } from '../../../../services/settings-crud/sms-lookup/sms-lookup.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { SmsLookupUpdateDto } from '../../../../models/settings-crud/sms-lookups/sms-lookup-update-dto';
import { SmsLookupDto } from '../../../../models/settings-crud/sms-lookups/sms-lookup-dto';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericDropdownComponent } from '../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { CompanyDto } from '../../../../models/settings-crud/companies/company-dto';
import { LookupDto } from '../../../../models/settings-crud/lookups/lookup-dto';
import { CompanyService } from '../../../../services/settings-crud/company/company.service';
import { LookupService } from '../../../../services/settings-crud/lookups/lookups.service';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';

@Component({
  selector: 'app-update-sms-lookup',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatDialogModule,
    TihGenericInputComponent,
    TihGenericDropdownComponent,
    TihGenericButtonComponent,   
    MatCardModule,
    MatFormFieldModule
  ],
  templateUrl: './update-sms-lookup.component.html',
  styleUrl: './update-sms-lookup.component.scss'
})
export class UpdateSmsLookupComponent implements OnInit {
  smsLookupFormGroup!: FormGroup;
  companies: CompanyDto[] = [];
  lookups: LookupDto[] = [];
  private formBuilder = inject(FormBuilder);
  private smsLookupService = inject(SmsLookupService);
  private toastService = inject(ToastService);
  private companyService = inject(CompanyService);
  private lookupService = inject(LookupService);
  public dialogRef = inject(MatDialogRef<UpdateSmsLookupComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<SmsLookupDto>;

  ngOnInit(): void {
    this.smsLookupFormGroup = this.formBuilder.group({
      id: [this.data.modelDto.id],
      title: [this.data.modelDto.title],
      englishMessage: [this.data.modelDto.englishMessage, Validators.required],
      afrikaansMessage: [this.data.modelDto.afrikaansMessage],
      typeId: [this.data.modelDto.typeId, Validators.required],
      companyId: [this.data.modelDto.companyId]
    });
    this.loadDropdownData();
  }

  loadDropdownData(): void {
    this.companyService.getCompanies().subscribe(companiesResponse => {
      this.companies = companiesResponse;
    });
    this.lookupService.getLookups().subscribe(lookupResponse => {
      this.lookups = lookupResponse;
    });
  }

  save(): void {
    if (this.smsLookupFormGroup.valid) {
      const formValue = this.smsLookupFormGroup.value;
      const smsLookupUpdateDto: SmsLookupUpdateDto = {
        title: formValue.title,
        englishMessage: formValue.englishMessage,
        afrikaansMessage: formValue.afrikaansMessage,
        typeId: formValue.typeId,
        companyId: formValue.companyId,
        isActive: this.data.modelDto.isActive
      };
      this.smsLookupService.updateSmsLookup(formValue.id, smsLookupUpdateDto).subscribe(updateResponse => {
        if (updateResponse) {
          this.toastService.success(updateResponse.message);
          this.dialogRef.close(updateResponse);
        }
      });
    }
  }

  cancel(): void {
    this.dialogRef.close();
  }
}