import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateSmsLookupComponent } from './update-sms-lookup.component';

describe('UpdateSmsLookupComponent', () => {
  let component: UpdateSmsLookupComponent;
  let fixture: ComponentFixture<UpdateSmsLookupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateSmsLookupComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(UpdateSmsLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});