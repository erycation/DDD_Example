import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddSmsLookupComponent } from './add-sms-lookup.component';

describe('AddSmsLookupComponent', () => {
  let component: AddSmsLookupComponent;
  let fixture: ComponentFixture<AddSmsLookupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddSmsLookupComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddSmsLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});