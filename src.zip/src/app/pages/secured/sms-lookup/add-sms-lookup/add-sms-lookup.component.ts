import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { SmsLookupService } from '../../../../services/settings-crud/sms-lookup/sms-lookup.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { SmsLookupAddDto } from '../../../../models/settings-crud/sms-lookups/sms-lookup-add-dto';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericDropdownComponent } from '../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericToggleComponent } from '../../../components/tih-generic-toggle/tih-generic-toggle.component';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { CompanyDto } from '../../../../models/settings-crud/companies/company-dto';
import { LookupDto } from '../../../../models/settings-crud/lookups/lookup-dto';
import { CompanyService } from '../../../../services/settings-crud/company/company.service';
import { LookupService } from '../../../../services/settings-crud/lookups/lookups.service';

@Component({
  selector: 'app-add-sms-lookup',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatDialogModule,
    TihGenericInputComponent,
    TihGenericDropdownComponent,
    TihGenericToggleComponent,
    TihGenericButtonComponent
  ],
  templateUrl: './add-sms-lookup.component.html',
  styleUrl: './add-sms-lookup.component.scss'
})
export class AddSmsLookupComponent implements OnInit {
  smsLookupFormGroup!: FormGroup;
  companies: CompanyDto[] = [];
  lookups: LookupDto[] = [];

  private formBuilder = inject(FormBuilder);
  private smsLookupService = inject(SmsLookupService);
  private toastService = inject(ToastService);
  private companyService = inject(CompanyService);
  private lookupService = inject(LookupService);
  public dialogRef = inject(MatDialogRef<AddSmsLookupComponent>);

  ngOnInit(): void {
    this.smsLookupFormGroup = this.formBuilder.group({
      title: [''],
      englishMessage: ['', Validators.required],
      afrikaansMessage: [''],
      typeId: [null, Validators.required],
      companyId: [null]
    });

    this.loadDropdownData();
  }

  loadDropdownData(): void {
    this.companyService.getCompanies().subscribe(companiesResponse => {
      this.companies = companiesResponse;
    });

    this.lookupService.getLookups().subscribe(lookupResponse => {
      this.lookups = lookupResponse;
    });
  }

  save(): void {
    if (this.smsLookupFormGroup.valid) {
      const formValue = this.smsLookupFormGroup.value;
      const smsLookupAddDto: SmsLookupAddDto = {
        title: formValue.title,
        englishMessage: formValue.englishMessage,
        afrikaansMessage: formValue.afrikaansMessage,
        typeId: formValue.typeId,
        companyId: formValue.companyId
      };
      this.smsLookupService.addSmsLookup(smsLookupAddDto).subscribe(addResponse => {
        if (addResponse) {
          this.toastService.success(addResponse.message);
          this.dialogRef.close(addResponse);
        }
      });
    }
  }

  cancel(): void {
    this.dialogRef.close();
  }
}