import { Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { CompanyDto } from '../../../models/settings-crud/companies/company-dto';
import { ViewOptions } from '../../../models/cdm-portal/page-settings.model';
import { Column } from '../../../models/cdm-portal/column.model';
import { Subject, Subscription } from 'rxjs';
import { CompanyService } from '../../../services/settings-crud/company/company.service';
import { TIHAdvancedTableComponent } from '../../components/advanced-table/advanced-table.component';
import { UpdateCompanyComponent } from './update-company/update-company.component';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { DataTableComponent } from '../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../components/tih-generic-button/tih-generic-button.component';
import { TableConfig } from '../../components/data-table/data-table.types';
import { CompanyUpdateDto } from '../../../models/settings-crud/companies/company-update-dto';
import { ToastService } from '../../../services/cdm-portal/notification/toast.service';
import { AddCompanyComponent } from './add-company/add-company.component';
import { UpdateData } from '../../../models/cdm-portal/utilities/updateData';

@Component({
  selector: 'app-company',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    TIHAdvancedTableComponent,
    CommonModule, 
    DataTableComponent, 
    TihGenericButtonComponent
  ],
  templateUrl: './company.component.html',
  styleUrl: './company.component.scss'
})
export class CompanyComponent {

  companiesDto: CompanyDto[] = [];
  pageSize = 5;
  pageSizeOptions = [5, 10, 25, 50, 100];
  defaultViewOptions: ViewOptions = {
    hasPagination: true,
    isSearchable: true,
    isSortable: true,
    labelAddNew: `Add New`,
    hasView: true,
    hasUpdate: true,
    hasDelete: false,
    hasAdd: true,
  };
  companyTableConfig!: TableConfig;
  viewOptions: ViewOptions = this.defaultViewOptions;
@ViewChild('actions') actionsTemplate!: TemplateRef<any>;
  columns: Column[] = [];

  theDestroyer: Subject<void> = new Subject();
  actioned: boolean = false;
  private subscription: Subscription | undefined;

  constructor(
    private companyService: CompanyService,
    public dialog: MatDialog,
    private router: Router
  ) {
    this.subscription = companyService.actioned$.subscribe(response => {
      this.actioned = response;
      if (this.actioned) {
        this.getCompanies();
      }
    })
  }

  private toast = inject(ToastService);

  ngAfterViewInit(): void{
    setTimeout(() => {
      this.companyTableConfig = {
        columns: [
          { field: 'name', header: 'Name', sortable: true },
          { field: 'companyCode', header: 'Company Code', sortable: true },
          { field: 'policyCompany', header: 'Policy Company', sortable: true },
          { field: 'underwritingCompany', header: 'Underwriting Company', sortable: true },
          { field: 'fspDetails', header: 'Fsp Details', sortable: true },
          { field: 'contactNumber', header: 'Contact Number', sortable: true },
          { field: 'brokerCode', header: 'Broker Code', sortable: true },
          { field: 'isActive', header: 'Enabled' }
        ],
        actionsTemplate: this.actionsTemplate,
        enableSearch: true,
        enableFilters: true,
        toggleFields: ['isActive'],
          onToggleChange: (updateRow) => this.toggleCompanyStatus(updateRow)
      };
    });
  }

  ngOnInit() {
    this.getCompanies();
  }

  getCompanies() {
    this.companyService.getCompanies().subscribe(companiesResponse => {
      if (companiesResponse) {
        this.companiesDto = companiesResponse;
      }
    })
  }

  toggleCompanyStatus(companyDto: CompanyDto): void {
      const companyUpdateDto: CompanyUpdateDto = { isActive: companyDto.isActive }
  
      this.companyService
        .updateCompany(companyDto.id!, companyUpdateDto)
        .subscribe(updateCompanyResponse => {
          if(updateCompanyResponse){
            this.toast.success(`${updateCompanyResponse.message}`); 
          }
        });
    }

  addNewCompany() {
   this.dialog.open(AddCompanyComponent, {
      width: '800px',
      data: {
        title: 'Add',
        message: '',
      },
      disableClose: true,
    });
  }

  

  updateCompany(companyDto: CompanyDto) {
    const companyUpdateData: UpdateData<CompanyDto> = {
        title: 'Update',
        message: '',
        modelDto : companyDto
      }

     this.dialog.open(UpdateCompanyComponent, {
      maxWidth: '1200px',
      data: companyUpdateData,
      disableClose: true,
    });
  }

  viewCompany(companyDto: CompanyDto) {
    //this.router.navigate(['/settings/systems-details', systemDto.id]);
  }
  
  ngOnDestroy(){
    this.subscription?.unsubscribe();
  }
}