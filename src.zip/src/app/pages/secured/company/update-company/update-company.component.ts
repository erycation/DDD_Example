import { Component, inject, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators,} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef,} from '@angular/material/dialog';
import { CompanyUpdateDto } from '../../../../models/settings-crud/companies/company-update-dto';
import { CompanyService } from '../../../../services/settings-crud/company/company.service';
import { CompanyDto } from '../../../../models/settings-crud/companies/company-dto';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { MatDividerModule } from '@angular/material/divider';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';

@Component({
  selector: 'app-update-company',
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    ReactiveFormsModule,
    TihGenericInputComponent,
    TihGenericButtonComponent,
    MatDividerModule
  ],
  templateUrl: './update-company.component.html',
  styleUrl: './update-company.component.scss',
})
export class UpdateCompanyComponent {
  companyFormGroup!: FormGroup;
  updateCompanyDto: CompanyUpdateDto | undefined;

  public dialogRef = inject(MatDialogRef<UpdateCompanyComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<CompanyDto>;
  private formBuilder = inject(FormBuilder);
  private companyService = inject(CompanyService);
  private toastService = inject(ToastService);

  ngOnInit() {
    this.populateFormGroup(this.data.modelDto);
  }

  populateFormGroup(companyDto: CompanyDto): void {
        this.companyFormGroup = this.formBuilder?.group({
        id: new FormControl(companyDto.id),
        name: new FormControl(companyDto.name, Validators.required),
        companyCode: new FormControl(companyDto.companyCode,Validators.required),
        policyCompany: new FormControl(companyDto.policyCompany,Validators.required),
        underwritingCompany: new FormControl(companyDto.underwritingCompany,Validators.required),
        fspDetails: new FormControl(companyDto.fspDetails),
        contactNumber: new FormControl(companyDto.contactNumber),
        brokerCode: new FormControl(companyDto.brokerCode, Validators.required)
      });
  }

  save() {
    const companyId = this.companyFormGroup.get('id')?.value;
    this.updateCompanyDto = {
      name: this.companyFormGroup.get('name')?.value,
      companyCode: this.companyFormGroup.get('companyCode')?.value,
      policyCompany: this.companyFormGroup.get('policyCompany')?.value,
      underwritingCompany: this.companyFormGroup.get('underwritingCompany')?.value,
      fspDetails: this.companyFormGroup.get('fspDetails')?.value,
      contactNumber: this.companyFormGroup.get('contactNumber')?.value,
      brokerCode: this.companyFormGroup.get('brokerCode')?.value
    };

    this.companyService
      .updateCompany(companyId, this.updateCompanyDto)
      .subscribe((companyUpdateResponse) => {
          this.toastService.success(companyUpdateResponse.message);
          this.companyFormGroup.reset();
          this.dialogRef.close();
          this.companyService.emitValue(true);
      });
  }
}