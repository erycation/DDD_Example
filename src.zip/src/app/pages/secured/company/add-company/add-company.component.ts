import { Component, Inject, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CompanyService } from '../../../../services/settings-crud/company/company.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { CompanyAddDto } from '../../../../models/settings-crud/companies/company-add-dto';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';

@Component({
  selector: 'app-add-company',
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    ReactiveFormsModule,
    TihGenericInputComponent,
    TihGenericButtonComponent,
    MatDividerModule
  ],
  templateUrl: './add-company.component.html',
  styleUrl: './add-company.component.scss',
})
export class AddCompanyComponent {
  companyFormGroup!: FormGroup;
  addCompanyDto!: CompanyAddDto;
  private companyService = inject(CompanyService);
  private toastService = inject(ToastService);
  private formBuilder = inject(FormBuilder);
  public data = inject(MAT_DIALOG_DATA) as any;
  public dialogRef = inject(MatDialogRef<AddCompanyComponent>);

  ngOnInit() {
    this.companyFormGroup = this.formBuilder?.group({
      name: new FormControl('', Validators.required),
      companyCode: new FormControl('', Validators.required),
      policyCompany: new FormControl('', Validators.required),
      underwritingCompany: new FormControl('', Validators.required),
      fspDetails: new FormControl(''),
      contactNumber: new FormControl(''),
      brokerCode: new FormControl('', Validators.required)
    });
  }

  closeDialog() {
    this.dialogRef.close();
  }

  addNewCompany() {
    this.addCompanyDto = {
      name: this.companyFormGroup.get('name')?.value,
      companyCode: this.companyFormGroup.get('companyCode')?.value,
      policyCompany: this.companyFormGroup.get('policyCompany')?.value,
      underwritingCompany: this.companyFormGroup.get('underwritingCompany')?.value,
      fspDetails: this.companyFormGroup.get('fspDetails')?.value,
      contactNumber: this.companyFormGroup.get('contactNumber')?.value,
      brokerCode: this.companyFormGroup.get('brokerCode')?.value
    };

    this.companyService
      .addCompany(this.addCompanyDto)
      .subscribe((companyAddResponse) => {
        this.toastService.success(companyAddResponse.message);
        this.companyFormGroup.reset();
        this.dialogRef.close();
        this.companyService.emitValue(true);
      });
  }
}
