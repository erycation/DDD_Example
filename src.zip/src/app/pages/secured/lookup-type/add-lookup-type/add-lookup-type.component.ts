import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule, FormArray } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { LookupTypeService } from '../../../../services/settings-crud/lookupType/lookupType.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { LookupTypeAddDto } from '../../../../models/settings-crud/lookup-types/lookup-type-add-dto';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericDropdownComponent } from '../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericToggleComponent } from '../../../components/tih-generic-toggle/tih-generic-toggle.component';
import { CommonModule } from '@angular/common';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';

@Component({
  selector: 'app-add-lookup-type',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatButtonModule,
    MatDialogModule,
    TihGenericInputComponent,
    TihGenericToggleComponent,
    TihGenericButtonComponent,
    TihGenericDropdownComponent
  ],
  templateUrl: './add-lookup-type.component.html',
  styleUrl: './add-lookup-type.component.scss'
})
export class AddLookupTypeComponent {
  lookupTypeFormGroup!: FormGroup;
  includeLookups: boolean = false
  rows: { code: number; name: string;  key: string }[] = [];

  private formBuilder = inject(FormBuilder);
  private lookupTypeService = inject(LookupTypeService);
  private toastService = inject(ToastService);
  public dialogRef = inject(MatDialogRef<AddLookupTypeComponent>);

  ngOnInit(): void {
    this.lookupTypeFormGroup = this.formBuilder.group({
      key: ['', Validators.required],
      description: ['', Validators.required],
      lookups: this.formBuilder.array([])
    });
  }

  get lookups(): FormArray {
    return this.lookupTypeFormGroup.get('lookups') as FormArray;
  }

  toggleAddLookups(){ this.includeLookups = !this.includeLookups }

  addRow() {
    const key = this.lookupTypeFormGroup.get('key')?.value;
    const row = this.formBuilder.group({
      code: [0, Validators.required],
      name: ['', Validators.required],
      key: [key]
    });
    this.lookups.push(row);
  }

  removeRow(index: number) {
    this.lookups.removeAt(index);
  }


  save(): void {
    const formValue = this.lookupTypeFormGroup.value;

    const dto: LookupTypeAddDto = {
      key: formValue.key,
      description: formValue.description,
      lookups: formValue.lookups.map((lookup: any) => ({
        code: lookup.code,
        name: lookup.name,
        key: lookup.key
      }))
    };

    if (this.lookupTypeFormGroup.valid) {
      this.lookupTypeService.addLookupType(dto).subscribe(lookupTypeAddresponse =>{
        if(lookupTypeAddresponse){
          this.toastService.success(lookupTypeAddresponse.message);
          this.dialogRef.close(lookupTypeAddresponse);
          this.lookupTypeService.emitValue(true);
        }
      })
    }
  }
}
