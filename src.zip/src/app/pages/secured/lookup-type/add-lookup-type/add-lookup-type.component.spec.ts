import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddLookupTypeComponent } from './add-lookup-type.component';

describe('AddLookupTypeComponent', () => {
  let component: AddLookupTypeComponent;
  let fixture: ComponentFixture<AddLookupTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddLookupTypeComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(AddLookupTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
