import { Component, inject, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { LookupTypeService } from '../../../../services/settings-crud/lookupType/lookupType.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { LookupTypeDto } from '../../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupTypeUpdateDto } from '../../../../models/settings-crud/lookup-types/lookup-type-update-dto';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericDropdownComponent } from '../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';

@Component({
  selector: 'app-update-lookup-type',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    TihGenericInputComponent,
    TihGenericButtonComponent,
    TihGenericDropdownComponent
  ],
  templateUrl: './update-lookup-type.component.html',
  styleUrl: './update-lookup-type.component.scss'
})
export class UpdateLookupTypeComponent {
  lookupTypeFormGroup!: FormGroup;
  updateLookupTypeDto!: LookupTypeUpdateDto;
  
  booleanOptions = [
      { label: 'True', value: true },
      { label: 'False', value: false }
  ];

  private lookupTypeService = inject(LookupTypeService);
  private toastService = inject(ToastService);
  private formBuilder = inject(FormBuilder);
  public dialogRef = inject(MatDialogRef<UpdateLookupTypeComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<LookupTypeDto>;

  ngOnInit() { 
    if (this.data.modelDto) {
        this.populateForm(this.data.modelDto);
    }
  }

  populateForm(lookupTypeDto: LookupTypeDto): void {
    this.lookupTypeFormGroup = this.formBuilder.group({
      key: new FormControl({ value: lookupTypeDto.key, disabled: true }),
      description: new FormControl(lookupTypeDto.description, Validators.required),
      isStatic: new FormControl(lookupTypeDto.isStatic),
    });
  }

  save(): void {
    if (this.lookupTypeFormGroup.valid) {

      this.updateLookupTypeDto = {
        description: this.lookupTypeFormGroup.get('description')?.value,
        isStatic: this.lookupTypeFormGroup.get('isStatic')?.value,
      };

      this.lookupTypeService.updateLookupType(this.data.modelDto!.key, this.updateLookupTypeDto).subscribe({
        next: (updatelookupTypeResponse) => {
          this.dialogRef.close(updatelookupTypeResponse);
          this.lookupTypeService.emitValue(true);
        }
      });
    }
  }
}
