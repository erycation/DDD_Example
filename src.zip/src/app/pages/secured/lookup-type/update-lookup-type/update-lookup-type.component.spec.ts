import { ComponentFixture, TestBed } from '@angular/core/testing';
import { UpdateLookupTypeComponent } from './update-lookup-type.component';

describe('UpdateLookupTypeComponent', () => {
  let component: UpdateLookupTypeComponent;
  let fixture: ComponentFixture<UpdateLookupTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateLookupTypeComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(UpdateLookupTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
