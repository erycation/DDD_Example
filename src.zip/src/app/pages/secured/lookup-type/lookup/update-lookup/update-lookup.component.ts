import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { UpdateData } from '../../../../../models/cdm-portal/utilities/updateData';
import { LookupDto } from '../../../../../models/settings-crud/lookups/lookup-dto';
import { LookupUpdateDto } from '../../../../../models/settings-crud/lookups/lookup-update-dto';
import { ToastService } from '../../../../../services/cdm-portal/notification/toast.service';
import { LookupService } from '../../../../../services/settings-crud/lookups/lookups.service';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { TihGenericDropdownComponent } from '../../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericInputComponent } from '../../../../components/tih-generic-input/tih-generic-input.component';
import { LookupTypeDto } from '../../../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupTypeService } from '../../../../../services/settings-crud/lookupType/lookupType.service';
import { TihGenericAutoCompleteComponent } from '../../../../components/tih-generic-dropdown/auto-complete/tih-generic-autocomplete.component';
import { CommonModule } from '@angular/common';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'app-update-lookup',
  standalone: true,
  imports: [
    FormsModule,
    MatButtonModule,
    MatCardModule,
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    ReactiveFormsModule,
    TihGenericInputComponent,
    TihGenericDropdownComponent,
    TihGenericButtonComponent,
  ],
  templateUrl: './update-lookup.component.html',
  styleUrl: './update-lookup.component.scss'
})

export class UpdateLookupComponent {

  lookupFormGroup!: FormGroup;
  updateLookupDto: LookupUpdateDto | undefined;

  private lookupService = inject(LookupService);
  private lookupTypeService = inject(LookupTypeService);
  private formBuilder = inject(FormBuilder);
  public dialogRef = inject(MatDialogRef<UpdateLookupComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<LookupDto>;

  ngOnInit() {
    this.populateUpsertFormGroup(this.data.modelDto);
  }

  populateUpsertFormGroup(lookupDto: LookupDto | undefined): void {
    if (lookupDto) {
      this.lookupFormGroup = this.formBuilder?.group({
        id: new FormControl(lookupDto.id),
        code: new FormControl(lookupDto.code, Validators.required),
        key: new FormControl(lookupDto.key, Validators.required),
        name: new FormControl(lookupDto.name, Validators.required),
        addedDateTime: new FormControl(lookupDto.addedDateTime),
        updatedDateTime: new FormControl(lookupDto.updatedDateTime)
      });
    }
  }

  save() {
  if (this.lookupFormGroup.get("id")?.value != undefined) {
    const lookupId = this.lookupFormGroup.get("id")?.value;

    this.lookupService.updateLookup(lookupId, {  
        code: this.lookupFormGroup.get('code')?.value,
        name: this.lookupFormGroup.get('name')?.value
      }).subscribe(
        (updateResponse) => {
          this.dialogRef.close(updateResponse); 
        }
      );
     }
   }
}