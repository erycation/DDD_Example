import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { LookupService } from '../../../../../services/settings-crud/lookups/lookups.service';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { TihGenericInputComponent } from '../../../../components/tih-generic-input/tih-generic-input.component';
import { CommonModule } from '@angular/common';
import { MatIcon } from '@angular/material/icon';
import { LookupTypeDto } from '../../../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupTypeService } from '../../../../../services/settings-crud/lookupType/lookupType.service';
import { TihGenericAutoCompleteComponent } from '../../../../components/tih-generic-dropdown/auto-complete/tih-generic-autocomplete.component';

@Component({
  selector: 'app-add-lookup',
  standalone: true,
  imports: [
    FormsModule,
    MatIcon,
    MatCardModule,
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatIcon,
    ReactiveFormsModule,
    TihGenericInputComponent, 
    TihGenericAutoCompleteComponent,
    TihGenericButtonComponent,
  ],
  templateUrl: './add-lookup.component.html',
  styleUrl: './add-lookup.component.scss'
})

export class AddLookupComponent {
  lookupFormGroup!: FormGroup;
  lookupTypeOptions: LookupTypeDto[] = [];
  showAutocomplete = false;
    
  private formBuilder = inject(FormBuilder);
  private lookupService = inject(LookupService);
  private lookupTypeService = inject(LookupTypeService);
  private selectedLookupType: LookupTypeDto | null = null;
  public dialogRef = inject(MatDialogRef<AddLookupComponent>);
  public data = inject(MAT_DIALOG_DATA);

  ngOnInit() {
    this.populateUpsertFormGroup();
  }

  populateUpsertFormGroup(): void {
      this.lookupFormGroup = this.formBuilder?.group({
        code: new FormControl('', Validators.required),
        name: new FormControl('', Validators.required),
        key: new FormControl(this.data.key),
      });
  }
  
  lookupTypeDisplay = (lookupType: LookupTypeDto) => `${lookupType.key?.trim()} - ${lookupType.description?.trim()}`;

  setLookupType(lookupType: LookupTypeDto): void {
    this.selectedLookupType = lookupType;
  }

  showLookupTypeKeys(){
    this.showAutocomplete = !this.showAutocomplete
    if(this.showAutocomplete) { this.loadDropdown(); }
  }

  loadDropdown() {
    if(this.lookupTypeOptions.length < 1){
      this.lookupTypeService.getLookupTypes().subscribe(lookupTypesResponse => {
        if (lookupTypesResponse) {
          this.lookupTypeOptions = lookupTypesResponse
        }
      });
    }
  }

  save() {
    this.lookupService.addLookup({  
      code:  this.lookupFormGroup.get('code')?.value,
      name:  this.lookupFormGroup.get('name')?.value,
      key: this.showAutocomplete 
          ? this.selectedLookupType?.key 
          : this.data.key
    }).subscribe(
      (updateResponse) => {
        this.dialogRef.close(updateResponse); 
      }
    );
  }
}