import { Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { LookupService } from '../../../../services/settings-crud/lookups/lookups.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { LookupTypeDto } from '../../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupQueryFilterDto } from '../../../../models/settings-crud/lookups/lookup-query-filter-dto';
import { LookupDto } from '../../../../models/settings-crud/lookups/lookup-dto';
import { TableConfig } from '../../../components/data-table/data-table.types';
import { DataTableComponent } from '../../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { ActivatedRoute } from '@angular/router';
import { LookupUpdateDto } from '../../../../models/settings-crud/lookups/lookup-update-dto';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';
import { ResponseApi } from '../../../../models/cdm-portal/response-api.model';
import { MatDialog } from '@angular/material/dialog';
import { UpdateLookupComponent } from './update-lookup/update-lookup.component';
import { AddLookupComponent } from './add-lookup/add-lookup.component';

@Component({
  selector: 'app-lookup',
  standalone: true,
  imports: [ DataTableComponent, TihGenericButtonComponent ],
  templateUrl: './lookup.component.html',
  styleUrl: './lookup.component.scss'
})

export class LookupComponent {
  private lookupService = inject(LookupService);
  private toast = inject(ToastService);
  private dialog = inject(MatDialog);
  private route = inject(ActivatedRoute);
  lookupsDto: LookupDto[] = [];
  lookupTableConfig!: TableConfig;
  lookupKey!: string;

  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;

  ngOnInit() { 
    this.route.paramMap.subscribe(params => {
      this.lookupKey = params.get('lookupKey') || "";

        const lookupQueryKey: LookupQueryFilterDto = { key: this.lookupKey };
        this.lookupService.getLookupsByQuery(lookupQueryKey).subscribe(lookupsResponse => {
          this.lookupsDto = lookupsResponse
      })
    })
  }

  ngAfterViewInit(): void{
    setTimeout(() => {
      this.lookupTableConfig = {
          columns: [
            { field: 'key', header: 'Key', sortable: true },
            { field: 'code', header: 'Code', sortable: true },
            { field: 'name', header: 'Name', sortable: true },
            { field: 'isActive', header: 'Enabled' }
          ],
          actionsTemplate: this.actionsTemplate,
          enableSearch: true,
          enableFilters: true,
          toggleFields: ['isActive'],
          onToggleChange: (updateRow) => this.toggleLookupStatus(updateRow)
        };
      });
  }

  toggleLookupStatus(lookupDto: LookupDto): void { 
    const lookupUpdateDto: LookupUpdateDto = { isActive: lookupDto.isActive }
  
      this.lookupService
        .updateLookup(lookupDto.id!, lookupUpdateDto)
        .subscribe(updateLookupResponse => {
          if(updateLookupResponse){
            this.toast.success(`${updateLookupResponse.message}`); 
          }
        });
  }

 editLookup(lookupUpdateDto: LookupDto): void {
  const lookupUpdateData: UpdateData<LookupDto> =
    {
      title: `Update Code: ${lookupUpdateDto.code}`,
      message: '',
      modelDto: lookupUpdateDto
    }

  var dialogRef = this.dialog.open(UpdateLookupComponent, {
    width: '800px',
    maxWidth: '1200px',
    data: lookupUpdateData,
    disableClose: true,
  });

  dialogRef.afterClosed()
    .subscribe((updateResult: ResponseApi<LookupDto>) => {
      if (updateResult) {
        var index: number = this.lookupsDto.findIndex(x => x.id === updateResult.data.id);
        this.lookupsDto[index] = updateResult.data;
        this.toast.success(updateResult.message);
      }
    });
  };

  addLookup(): void {
    var dialogRef = this.dialog.open(AddLookupComponent, {
      width: '800px',
      data: { title: 'Add Lookup', key: this.lookupKey },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((addLookupResult: ResponseApi<LookupTypeDto>) => {
        if (addLookupResult.data.key === this.lookupKey) {
          this.lookupsDto.push(addLookupResult.data);
          this.toast.success(addLookupResult.message);
        }
      });
  }
}