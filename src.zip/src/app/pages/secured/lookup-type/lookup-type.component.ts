import { Component, ViewChild, TemplateRef, AfterViewInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableConfig } from '../../components/data-table/data-table.types';
import { DataTableComponent } from '../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../components/tih-generic-button/tih-generic-button.component';
import { LookupTypeDto } from '../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupTypeService } from '../../../services/settings-crud/lookupType/lookupType.service';
import { MatDialog } from '@angular/material/dialog';
import { ToastService } from '../../../services/cdm-portal/notification/toast.service';
import { LookupTypeUpdateDto } from '../../../models/settings-crud/lookup-types/lookup-type-update-dto';
import { UpdateLookupTypeComponent } from './update-lookup-type/update-lookup-type.component';
import { AddLookupTypeComponent } from './add-lookup-type/add-lookup-type.component';
import { UpdateData } from '../../../models/cdm-portal/utilities/updateData';
import { Router } from '@angular/router';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';


@Component({
  selector: 'app-lookup-type',
  standalone: true,
  imports: [CommonModule, DataTableComponent, TihGenericButtonComponent],
  templateUrl: './lookup-type.component.html',
  styleUrl: './lookup-type.component.scss'
})
export class LookupTypeComponent implements AfterViewInit {
  lookupTypesDto: LookupTypeDto[] = [];
  lookupTypeTableConfig!: TableConfig;

  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;

  private lookupTypeService = inject(LookupTypeService);
  private toastService = inject(ToastService);
  public dialog = inject(MatDialog);
  private router = inject(Router);

  ngAfterViewInit(): void{
    setTimeout(() => {
      this.lookupTypeTableConfig = {
        columns: [
          { field: 'key', header: 'Key', sortable: true },
          { field: 'description', header: 'Description', sortable: true },
          { field: 'isActive', header: 'Active' }
        ],
        actionsTemplate: this.actionsTemplate,
        enableSearch: true,
        enableFilters: true,
        toggleFields: ['isActive'],
        onToggleChange: (updateRow) => this.updateLookupTypeStatus(updateRow)
      };
    });
  }
  
  ngOnInit(): void {
    this.lookupTypeService.getLookupTypes().subscribe(lookupTypesResponse => {
        this.lookupTypesDto = lookupTypesResponse;
    });
  }

  updateLookupTypeStatus(lookupTypeDto : LookupTypeDto): void {
    const lookupTypeUpdateDto : LookupTypeUpdateDto = 
          { isActive:lookupTypeDto.isActive,updatedById : lookupTypeDto.updatedById };
    this.lookupTypeService.updateLookupType(lookupTypeDto.key!, lookupTypeUpdateDto)
        .subscribe(lookupTypeUpdateResponse =>{
      if (lookupTypeUpdateResponse){
        this.lookupTypeService.emitValue(true);
      }
    });
  }

  viewLookup(lookupTypeDto: LookupTypeDto){
      this.router.navigate([`lookup-types/lookup/${lookupTypeDto.key}` ]);
  }

  editLookupType(lookupTypeDto: LookupTypeDto) {
  const updateData: UpdateData<LookupTypeDto> = {
    title: `Update Lookup Type: ${lookupTypeDto.key}`,
    message: '',
    modelDto: lookupTypeDto
  };
  var dialogRef = this.dialog.open(UpdateLookupTypeComponent, {
    width: '800px',
    data: updateData,
    disableClose: true
  });
   dialogRef.afterClosed().subscribe((result: ResponseApi<LookupTypeDto>) => {
        if (result) {
          var index: number = this.lookupTypesDto.findIndex(x => x.key === result.data.key);
          this.lookupTypesDto[index] = result.data;
          this.toastService.success(result.message);
        }
      });
  }

  addLookupType(): void {
  var dialogRef = this.dialog.open(AddLookupTypeComponent, {
    width: '800px',
    maxWidth: '1200px',
    data: { title: 'Add Lookup Type' },
    disableClose: true
  });
  dialogRef.afterClosed().subscribe((addLookupTypeResult: ResponseApi<LookupTypeDto>) => {
      if (addLookupTypeResult) {
        this.lookupTypesDto.push(addLookupTypeResult.data);
        this.toastService.success(addLookupTypeResult.message);
      }
    });
}
}
