import { Component, ViewChild, TemplateRef, AfterViewInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableConfig } from '../../components/data-table/data-table.types';
import { DataTableComponent } from '../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../components/tih-generic-button/tih-generic-button.component';
import { BrandDto } from '../../../models/settings-crud/brands/brand-dto';
import { BrandService } from '../../../services/settings-crud/brand/brand.service';
import { MatDialog } from '@angular/material/dialog';
import { ToastService } from '../../../services/cdm-portal/notification/toast.service';
import { BrandUpdateDto } from '../../../models/settings-crud/brands/brand-update-dto';
import { UpdateBrandComponent } from './update-brand/update-brand.component';
import { AddBrandComponent } from './add-brand/add-brand.component';
import { UpdateData } from '../../../models/cdm-portal/utilities/updateData';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
@Component({
  selector: 'app-brand',
  standalone: true,
  imports: [CommonModule, DataTableComponent, TihGenericButtonComponent],
  templateUrl: './brand.component.html',
  styleUrl: './brand.component.scss'
})
export class BrandComponent implements AfterViewInit {
  brandsDto: BrandDto[] = [];
  brandTableConfig!: TableConfig;

  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;

  private brandService = inject(BrandService);
  private toastService = inject(ToastService);
  public dialog = inject(MatDialog);
 
  ngAfterViewInit(): void{
    setTimeout(() => {
      this.brandTableConfig = {
        columns: [
          { field: 'brandName', header: 'Brand Name', sortable: true },
          { field: 'brandCode', header: 'Brand Code', sortable: true },
          { field: 'businessIdentifier', header: 'Business Identifier', sortable: true },
          { field: 'companyCode', header: 'Company Code', sortable: true },
          { field: 'underwritingCompany', header: 'Underwriting Company', sortable: true },
          { field: 'saleType', header: 'Sale Type', sortable: true },          
          { field: 'isActive', header: 'Enabled' }
        ],
        actionsTemplate: this.actionsTemplate,
        enableSearch: true,
        enableFilters: true,
        toggleFields: ['isActive'],
        onToggleChange: (updateRow) => this.updateBrandStatus(updateRow)
      };
    });
  }
  
  ngOnInit(): void {
    this.brandService.getBrands().subscribe(brandsResponse => {
        this.brandsDto = brandsResponse;
    });
  }

  updateBrandStatus(brandDto : BrandDto): void {
    const brandUpdateDto : BrandUpdateDto = 
          { isActive:brandDto.isActive };
    this.brandService.updateBrand(brandDto.id!, brandUpdateDto)
        .subscribe(brandUpdateResponse =>{
      if (brandUpdateResponse){
        this.brandService.emitValue(true);
      }
    });
  }

  editBrand(brandDto: BrandDto) {
    const brandUpdateData: UpdateData<BrandDto> = {
      title: `Update Brand: ${brandDto.id}`,
      message: '',
      modelDto: brandDto
    };
    var dialogRef = this.dialog.open(UpdateBrandComponent, {
      maxWidth: '1200px',
      data: brandUpdateData,
      disableClose: true
    });
    
    dialogRef.afterClosed().subscribe((result: ResponseApi<BrandDto>) => {
      if (result) {
        var index: number = this.brandsDto.findIndex(x => x.id === result.data.id);
        this.brandsDto[index] = result.data;
        this.toastService.success(result.message);
      }
    });
  }

  addNewBrand(): void {
    var dialogRef = this.dialog.open(AddBrandComponent, {
        maxWidth: '1200px',
      data: { 
        title: 'Add Brand'
      },
      disableClose: true
    });

    dialogRef.afterClosed().subscribe((addBrandResult: ResponseApi<BrandDto>) => {
      if (addBrandResult) {
        this.brandsDto.push(addBrandResult.data);
        this.toastService.success(addBrandResult.message);
      }
    });
  }
}
