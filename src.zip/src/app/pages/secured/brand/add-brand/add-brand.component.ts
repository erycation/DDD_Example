import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { BrandService } from '../../../../services/settings-crud/brand/brand.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { BrandAddDto } from '../../../../models/settings-crud/brands/brand-add-dto';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';

@Component({
  selector: 'app-add-brand',
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    ReactiveFormsModule,
    TihGenericInputComponent,
    TihGenericButtonComponent,
    MatDividerModule
  ],
  templateUrl: './add-brand.component.html',
  styleUrl: './add-brand.component.scss',
})

export class AddBrandComponent {
  brandFormGroup!: FormGroup;
  addBrandDto!: BrandAddDto;
  private brandService = inject(BrandService);
  private toastService = inject(ToastService);
  private formBuilder = inject(FormBuilder);
  public data = inject(MAT_DIALOG_DATA) as any;
  public dialogRef = inject(MatDialogRef<AddBrandComponent>);

  ngOnInit() {
    this.brandFormGroup = this.formBuilder?.group({
      brandName: new FormControl('', Validators.required),
      brandCode: new FormControl('', Validators.required),
      businessIdentifier: new FormControl('', Validators.required),
      companyCode: new FormControl('', Validators.required),
      underwritingCompany: new FormControl('', Validators.required),
      saleType: new FormControl('', Validators.required)      
    });
  }

  addNewBrand() {
    this.addBrandDto = {
      brandName: this.brandFormGroup.get('brandName')?.value,
      brandCode: this.brandFormGroup.get('brandCode')?.value,      
      businessIdentifier: this.brandFormGroup.get('businessIdentifier')?.value,
      companyCode: this.brandFormGroup.get('companyCode')?.value,     
      underwritingCompany: this.brandFormGroup.get('underwritingCompany')?.value,
      saleType: this.brandFormGroup.get('saleType')?.value     
    };
    if (this.brandFormGroup.valid) {
        this.brandService
        .addBrand(this.addBrandDto)
        .subscribe(brandAddResponse => {
          if(brandAddResponse){
            this.toastService.success(brandAddResponse.message);
            this.dialogRef.close(brandAddResponse);
            this.brandService.emitValue(true);
          }
        })
      }
  }
  
  closeDialog() {
    this.dialogRef.close();
  }
}