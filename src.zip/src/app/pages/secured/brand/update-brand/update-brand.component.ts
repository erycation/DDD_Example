import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators,} from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef,} from '@angular/material/dialog';
import { BrandUpdateDto } from '../../../../models/settings-crud/brands/brand-update-dto';
import { BrandService } from '../../../../services/settings-crud/brand/brand.service';
import { BrandDto } from '../../../../models/settings-crud/brands/brand-dto';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { MatDividerModule } from '@angular/material/divider';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-update-brand',
  standalone: true,
  imports: [
    FormsModule,
    MatDialogModule,
    ReactiveFormsModule,
    CommonModule,
    TihGenericInputComponent,
    TihGenericButtonComponent,
    MatDividerModule
  ],
  templateUrl: './update-brand.component.html',
  styleUrl: './update-brand.component.scss',
})
export class UpdateBrandComponent {
  brandFormGroup!: FormGroup;
  updateBrandDto: BrandUpdateDto | undefined;

  public dialogRef = inject(MatDialogRef<UpdateBrandComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<BrandDto>;
  private formBuilder = inject(FormBuilder);
  private brandService = inject(BrandService);
  private toastService = inject(ToastService);

  ngOnInit() {
    this.populateFormGroup(this.data.modelDto);
  }

  populateFormGroup(brandDto: BrandDto): void {
        this.brandFormGroup = this.formBuilder?.group({
        id: new FormControl(brandDto.id),
        brandName: new FormControl(brandDto.brandName, Validators.required),
        brandCode: new FormControl(brandDto.brandCode, Validators.required),
        businessIdentifier: new FormControl(brandDto.businessIdentifier,Validators.required),
        companyCode: new FormControl(brandDto.companyCode,Validators.required),
        underwritingCompany: new FormControl(brandDto.underwritingCompany, Validators.required),
        saleType: new FormControl(brandDto.saleType,Validators.required)
      });
  }

  save() {
    const brandId = this.brandFormGroup.get('id')?.value;
    this.updateBrandDto = {
      brandName: this.brandFormGroup.get('brandName')?.value,
      brandCode: this.brandFormGroup.get('brandCode')?.value,
      businessIdentifier: this.brandFormGroup.get('businessIdentifier')?.value,
      companyCode: this.brandFormGroup.get('companyCode')?.value,
      underwritingCompany: this.brandFormGroup.get('underwritingCompany')?.value,
      saleType: this.brandFormGroup.get('saleType')?.value
    };

    this.brandService
      .updateBrand(brandId, this.updateBrandDto)
      .subscribe((brandUpdateResponse) => {
          this.toastService.success(brandUpdateResponse.message);
          this.brandFormGroup.reset();
          this.dialogRef.close(brandUpdateResponse);
          this.brandService.emitValue(true);
      });
  }
}
