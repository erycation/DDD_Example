import { Component, inject, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { CampaignService } from '../../../../services/settings-crud/campaign/campaign.service';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { CampaignUpdateDto } from '../../../../models/settings-crud/campaigns/campaign-update-dto';
import { CampaignDto } from '../../../../models/settings-crud/campaigns/campaign-dto';
import { LookupDto } from '../../../../models/settings-crud/lookups/lookup-dto';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericDropdownComponent } from '../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { UpdateData } from '../../../../models/cdm-portal/utilities/updateData';
import { LookupService } from '../../../../services/settings-crud/lookups/lookups.service';
import { LookupQueryFilterDto } from '../../../../models/settings-crud/lookups/lookup-query-filter-dto';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';

@Component({
  selector: 'app-update-campaign',
  standalone: true,
  imports: [
    FormsModule,
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSelectModule,
    ReactiveFormsModule,
    TihGenericInputComponent,
    TihGenericDropdownComponent,
    TihGenericButtonComponent,
  ],
  templateUrl: './update-campaign.component.html',
  styleUrl: './update-campaign.component.scss'
})

export class UpdateCampaignComponent {

  campaignFormGroup!: FormGroup;
  updateCampaignDto: CampaignUpdateDto | undefined;
  businessUnitOptions: LookupDto[] = [];
  businessFunctionOptions: LookupDto[] = [];
  campaignModeOptions: LookupDto[] = [];

  private campaignService = inject(CampaignService);
  private lookupService = inject(LookupService);
  private toastService = inject(ToastService);
  private formBuilder = inject(FormBuilder);
  public dialogRef = inject(MatDialogRef<UpdateCampaignComponent>);
  public data = inject(MAT_DIALOG_DATA) as UpdateData<CampaignDto>;

  ngOnInit() {
    this.populateFormGroup(this.data.modelDto);
    this.loadDropdown(); 
  }

  populateFormGroup(campaignDto: CampaignDto | undefined): void {
    if (campaignDto) {
      this.campaignFormGroup = this.formBuilder?.group({
        id: new FormControl(campaignDto.id),
        businessFunction: new FormControl(campaignDto.businessFunctionDto?.id, Validators.required),
        campaignMode: new FormControl(campaignDto.campaignModeDto?.id, Validators.required),
        businessUnit: new FormControl(campaignDto.businessUnitDto?.id, Validators.required)
      });
    }
  }

loadDropdown() {
  const loadLookup = (dtoKey: string | undefined, setOptions: (data: any) => void) => {
    if (!dtoKey) return;
    const queryData: LookupQueryFilterDto = { key: dtoKey };
    this.lookupService.getLookupsByQuery(queryData).subscribe(queryResponse => {
      if (queryResponse) {
        setOptions(queryResponse);
      }
    });
  };
  loadLookup("BU", businessUnitData => this.businessUnitOptions = businessUnitData);
  loadLookup("BF", businessFunctionData => this.businessFunctionOptions = businessFunctionData);
}

  save() {
  if (this.campaignFormGroup.get("id")?.value != undefined) {
    const campaignId = this.campaignFormGroup.get("id")?.value;
    this.updateCampaignDto = {
      businessFunctionId: this.campaignFormGroup.get("businessFunction")?.value,
      businessUnitId: this.campaignFormGroup.get("businessUnit")?.value,
    }
    this.campaignService.updateCampaign(campaignId, this.updateCampaignDto).subscribe(campaignUpdateResponse => {
      if (campaignUpdateResponse) {
        this.dialogRef.close(campaignUpdateResponse);
        this.campaignService.emitValue(true);
        }
      })
     }
  }
}