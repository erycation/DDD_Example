import { Component, inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { SmsSettingsDialogData } from '../../../../../../models/cdm-portal/utilities/sms-settings-dialog-data';
import { TihGenericInputComponent } from '../../../../../components/tih-generic-input/tih-generic-input.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TihGenericButtonComponent } from '../../../../../components/tih-generic-button/tih-generic-button.component';
import { SmsSettingsService } from '../../../../../../services/settings-crud/sms-settings/sms-settings.service';
import { SmsUpdateDto } from '../../../../../../models/settings-crud/smses/sms-update-dto';
import { ResponseApi } from '../../../../../../models/cdm-portal/response-api.model';
import { SmsDto } from '../../../../../../models/settings-crud/smses/sms-dto';

@Component({
  selector: 'app-update-sms-settings',
  standalone: true,
  imports: [
    TihGenericInputComponent, MatDialogModule,
    TihGenericButtonComponent
  ],
  templateUrl: './update-sms-settings.component.html',
  styleUrl: './update-sms-settings.component.scss'
})
export class UpdateSmsSettingsComponent {
  data = inject(MAT_DIALOG_DATA) as SmsSettingsDialogData;
  dialogRef = inject(MatDialogRef<UpdateSmsSettingsComponent>);
  formBuilder = inject(FormBuilder);
  smsSettingsService = inject(SmsSettingsService);

  smsSettingsForm: FormGroup = new FormGroup({});

  ngOnInit(): void {
    this.setupForm();
  }
  
  setupForm(): void {
    this.smsSettingsForm = this.formBuilder.group({
      attempt: new FormControl(this.data.attempt, Validators.required),
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }

  saveSmsSettings(): void {
    if (this.smsSettingsForm.valid) {
      var smsSettingsUpdateDto = {
        attempt: this.smsSettingsForm.value.attempt,
      } as SmsUpdateDto;

      this.smsSettingsService.updateSmsSettings(this.data.id!, smsSettingsUpdateDto)
        .subscribe((updateResponse: ResponseApi<SmsDto>) => {
          this.dialogRef.close(updateResponse);
        });
    }
  }
}
