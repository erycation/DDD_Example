import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSmsSettingsComponent } from './add-sms-settings.component';

describe('AddSmsSettingsComponent', () => {
  let component: AddSmsSettingsComponent;
  let fixture: ComponentFixture<AddSmsSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddSmsSettingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddSmsSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
