import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSmsSettingsComponent } from './update-sms-settings.component';

describe('UpdateSmsSettingsComponent', () => {
  let component: UpdateSmsSettingsComponent;
  let fixture: ComponentFixture<UpdateSmsSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateSmsSettingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateSmsSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
