import { Component, inject, Input, TemplateRef, ViewChild } from '@angular/core';
import { TableConfig } from '../../../../components/data-table/data-table.types';
import { SmsDto } from '../../../../../models/settings-crud/smses/sms-dto';
import { SmsSettingsService } from '../../../../../services/settings-crud/sms-settings/sms-settings.service';
import { SmsQueryFilterDto } from '../../../../../models/settings-crud/smses/sms-query-filter-dto';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { DataTableComponent } from '../../../../components/data-table/data-table.component';
import { ToastService } from '../../../../../services/cdm-portal/notification/toast.service';
import { ResponseApi } from '../../../../../models/cdm-portal/response-api.model';
import { MatDialog } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { UpdateSmsSettingsComponent } from './update-sms-settings/update-sms-settings.component';
import { SmsSettingsDialogData } from '../../../../../models/cdm-portal/utilities/sms-settings-dialog-data';
import { SmsTableData } from '../../../../../models/cdm-portal/utilities/sms-table-data';
import { ContactStoreContextService } from '../../../../../services/settings-crud/contact-store/contact-store-context.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sms-settings',
  standalone: true,
  imports: [CommonModule, DataTableComponent, TihGenericButtonComponent],
  templateUrl: './sms-settings.component.html',
  styleUrl: './sms-settings.component.scss'
})
export class SmsSettingsComponent {
  @ViewChild('actions') actionsTemplate!: TemplateRef<HTMLElement>;

  public contactStoreId!: number;
  public smsSettingsTableConfig: TableConfig = {} as TableConfig;
  private smsSettingsService = inject(SmsSettingsService);
  private toastService = inject(ToastService);
  private editDialog = inject(MatDialog);
  private contactStoreContextService = inject(ContactStoreContextService);
  private router = inject(Router);
  
  smsDtos: SmsDto[] = [];
  tableData: Array<SmsTableData> = [];

  ngOnInit() {
    this.contactStoreId = this.contactStoreContextService.getContactStoreId();
    this.fetchSmsSettings();
  }

  ngAfterViewInit() {
    this.smsSettingsTableConfig = {
      columns: [
        { field: 'smsType', header: 'SMS Type', sortable: true },
        { field: 'attempt', header: 'Attempts', sortable: true },
        { field: 'englishMessage', header: 'English Message', sortable: true },
        { field: 'afrikaansMessage', header: 'Afrikaans Message', sortable: true },
        { field: 'isActive', header: 'Enabled' }
      ],
      actionsTemplate: this.actionsTemplate,
      enableSearch: true,
      enableFilters: true,
      toggleFields: ['isActive'],
      onToggleChange: (updateRow) => this.toggleActiveStatus(updateRow)
    };
  }

  toggleActiveStatus(updateRow: any): void {
    if(updateRow){
      this.smsSettingsService.updateSmsSettings(updateRow.id!, { isActive: updateRow.isActive })
        .subscribe((updateResponse: ResponseApi<SmsDto>) => {
          this.toastService.success(updateResponse.message);
        });
    }
  }

  fetchSmsSettings(): void {
    var smsQueryFilter = { contactStoreId: this.contactStoreId } as SmsQueryFilterDto;
    this.smsSettingsService.getSmsSettings(smsQueryFilter).subscribe((smsDtos: SmsDto[]) => {
      this.smsDtos = smsDtos;
      smsDtos.forEach((smsDto: SmsDto) => {
        var tableRow = {
          id: smsDto.id,
          englishMessage: smsDto.smsLookup?.englishMessage,
          afrikaansMessage: smsDto.smsLookup?.afrikaansMessage,
          isActive: smsDto.isActive,
          attempt: smsDto.attempt,
          smsType: smsDto.smsLookup?.smsType?.name
        } as SmsTableData;

        this.tableData.push(tableRow)
      });
    });
  }

  editSmsSettings(tableDataRow: SmsTableData): void {
    var dialogData = {
      attempt: tableDataRow.attempt,
      type: tableDataRow.smsType,
      id: tableDataRow.id
    } as SmsSettingsDialogData

    var dialogRef = this.editDialog.open(UpdateSmsSettingsComponent, {
      height: '40vh',
      minWidth: '45vw',
      data: dialogData
    });

    dialogRef.afterClosed().subscribe((result: ResponseApi<SmsDto>) => {
      if (result) {
        var index: number = this.tableData.findIndex(x => x.id === result.data.id);
        var updateTableRow = tableDataRow;
        updateTableRow.attempt = result.data.attempt!;
        this.tableData[index] = updateTableRow;
        this.toastService.success("SMS Settings updated successfully.");
      }
    });
  }

  addSmsSettings(): void {
    this.router.navigate(['/contact-store/sms-settings', this.contactStoreId, 'add']);
  }
}