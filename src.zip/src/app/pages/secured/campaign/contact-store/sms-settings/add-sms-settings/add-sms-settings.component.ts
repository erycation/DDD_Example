import { Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { DataTableComponent } from '../../../../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../../../../components/tih-generic-button/tih-generic-button.component';
import { TableConfig } from '../../../../../components/data-table/data-table.types';
import { SmsLookupService } from '../../../../../../services/settings-crud/sms-lookup/sms-lookup.service';
import { SmsLookupDto } from '../../../../../../models/settings-crud/sms-lookups/sms-lookup-dto';
import { SmsDto } from '../../../../../../models/settings-crud/smses/sms-dto';
import { SmsTableData } from '../../../../../../models/cdm-portal/utilities/sms-table-data';
import { SmsLookupQueryFilter } from '../../../../../../models/settings-crud/sms-lookups/sms-lookup-query-filter';
import { TihGenericCheckboxComponent } from '../../../../../components/tih-generic-checkbox/tih-generic-checkbox.component';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TihGenericInputComponent } from "../../../../../components/tih-generic-input/tih-generic-input.component";
import { CommonModule } from '@angular/common';
import { SmsAddDto } from '../../../../../../models/settings-crud/smses/sms-add-dto';
import { SmsSettingsService } from '../../../../../../services/settings-crud/sms-settings/sms-settings.service';
import { ToastService } from '../../../../../../services/cdm-portal/notification/toast.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-sms-settings',
  standalone: true,
  imports: [
    DataTableComponent, TihGenericButtonComponent,
    TihGenericCheckboxComponent, TihGenericInputComponent,
    CommonModule
],
  templateUrl: './add-sms-settings.component.html',
  styleUrl: './add-sms-settings.component.scss'
})
export class AddSmsSettingsComponent {
  @ViewChild('actions') actionsTemplate!: TemplateRef<HTMLElement>;

  public smsTemplates: Array<SmsDto> = [];
  public tableData: Array<SmsTableData> = [];
  public smsSettingsTableConfig: TableConfig = {} as TableConfig;
  public smsSettingsForm: FormGroup = new FormGroup({});
  public contactStoreId: number = 0;
  public selectedTemplate: SelectedTemplate[] = [];
  public checkedTemplates: number[] = [];
  private formBuilder = inject(FormBuilder);
  private smsLookupService = inject(SmsLookupService);
  private smsSettingsService = inject(SmsSettingsService);
  private toastService = inject(ToastService);
  private activatedRoute = inject(ActivatedRoute);
  
  ngAfterViewInit(): void {
    this.smsSettingsTableConfig = {
      columns: [
        { field: 'smsType', header: 'SMS Type', sortable: true },
        { field: 'englishMessage', header: 'English Message', sortable: true },
        { field: 'afrikaansMessage', header: 'Afrikaans Message', sortable: true },
      ],
      actionsTemplate: this.actionsTemplate,
      enableSearch: true,
      enableFilters: true
    } as TableConfig;
  }

  ngOnInit(): void {
    this.getContactStoreId();
    this.setupForm();
    this.fetchSmsTemplates();
  }

  getContactStoreId(): void {
    this.activatedRoute.paramMap.subscribe(params => {
      const contactStoreId = params.get('contactStoreId');
      if (contactStoreId) {
        this.contactStoreId = Number.parseInt(contactStoreId);
      }
    });
  }

  setupForm(): void {
    this.smsSettingsForm = this.formBuilder.group({
      attempt: new FormControl(''),
    });
  }

  fetchSmsTemplates(): void {
    var query = { isActive: true } as SmsLookupQueryFilter;
    this.smsLookupService.getSmsLookupsByQuery(query)
      .subscribe((templatesResponse: SmsLookupDto[]) => {
        templatesResponse.forEach((template: SmsLookupDto) => {
          var tableRow = {
            id: template.id,
            englishMessage: template.englishMessage,
            afrikaansMessage: template.afrikaansMessage,
            smsType: template?.smsType?.name
          } as SmsTableData;

          this.tableData.push(tableRow)
        });
      });
  }

  addSmsSettings(attempt: string, row: SmsTableData): void {
    var index = this.selectedTemplate.findIndex(template => template.id === row.id);
    if(attempt === '' && index !== -1){
      this.selectedTemplate.splice(index, 1);
      return;
    }

    var attemptNum = Number.parseInt(attempt);
    if(Number.isNaN(attemptNum) || attemptNum < 0) return;
    if (index !== -1) {
        this.selectedTemplate[index].attempt = attemptNum;
    }else{
      this.selectedTemplate.push({ id: row.id, attempt: attemptNum } as SelectedTemplate);
    }
  }

  appendCheckedTemplate(isChecked: boolean, row: SmsTableData): void {
    if(isChecked){
      this.checkedTemplates.push(row.id);
    }
      
    else{
      this.checkedTemplates = this.checkedTemplates.filter(id => id !== row.id);
      this.selectedTemplate = this.selectedTemplate.filter(template => template.id !== row.id);
    } 
  }

  isTemplateSelected(id: number): boolean {
    return this.checkedTemplates.includes(id);
  }

  showSubmitButton(): boolean {
    return this.checkedTemplates.length > 0;
  }

  submit(): void {
    var smsAddDtos: SmsAddDto[] = [];
    this.selectedTemplate.forEach((template: SelectedTemplate) => {
      var smsAddDto: SmsAddDto = {
        attempt: template.attempt,
        smsLookupId: template.id,
        contactStoreId: this.contactStoreId
      }
      smsAddDtos.push(smsAddDto);
    });

    this.smsSettingsService.addBulkSmsSettings(smsAddDtos)
      .subscribe((response) => {
        this.toastService.success(response.message);
      });
  }
}

interface SelectedTemplate{
  id: number;
  attempt: number;
}
