import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VdnComponent } from './vdn.component';

describe('VdnSettingsComponent', () => {
  let component: VdnComponent;
  let fixture: ComponentFixture<VdnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [VdnComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VdnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
