import { Component, inject, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { Subject, Subscription } from 'rxjs';
import { CommonModule } from '@angular/common';
import { Column } from '../../../../../models/cdm-portal/column.model';
import { ViewOptions } from '../../../../../models/cdm-portal/page-settings.model';
import { ToastService } from '../../../../../services/cdm-portal/notification/toast.service';
import { TIHAdvancedTableComponent } from '../../../../components/advanced-table/advanced-table.component';
import { DataTableComponent } from '../../../../components/data-table/data-table.component';
import { TableConfig } from '../../../../components/data-table/data-table.types';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { VdnDto } from '../../../../../models/settings-crud/vdns/vdn-dto';
import { VdnService } from '../../../../../services/settings-crud/vdn/vdn.service';
import { VdnQueryFilter } from '../../../../../models/settings-crud/vdns/vdn-query-filter';

@Component({
  selector: 'app-vdn',
  standalone: true,
  imports: [
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    TIHAdvancedTableComponent,
    CommonModule,
    DataTableComponent,
    TihGenericButtonComponent,
  ],
  templateUrl: './vdn.component.html',
  styleUrl: './vdn.component.scss',
})
export class VdnComponent {
  @Input() contactStoreId: number = 0;
  vdnQueryFilter: VdnQueryFilter | undefined;
  vdnDto: VdnDto[] = [];
  pageSize = 5;
  pageSizeOptions = [5, 10, 25, 50, 100];
  defaultViewOptions: ViewOptions = {
    hasPagination: true,
    isSearchable: true,
    isSortable: true,
    labelAddNew: `Link Vdn`,
    hasView: true,
    hasUpdate: true,
    hasDelete: false,
    hasAdd: true,
  };

  vdnService = inject(VdnService);
  dialog = inject(MatDialog);
  toast = inject(ToastService);
  vdnTableConfig!: TableConfig;
  viewOptions: ViewOptions = this.defaultViewOptions;
  @ViewChild('actions') actionsTemplate!: TemplateRef<any>;
  columns: Column[] = [];

  theDestroyer: Subject<void> = new Subject();
  actioned: boolean = false;
  private subscription: Subscription | undefined;

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.vdnTableConfig = {
        columns: [
          { field: 'vdnNo', header: 'Vdn Number', sortable: true },
          { field: 'contactStoreId', header: 'ContactStoreId', sortable: true },
          { field: 'smsCampaignId', header: 'Sms CampaignId', sortable: true },
          { field: 'campaignStory', header: 'Campaign Story', sortable: true },
          { field: 'agentScript', header: 'Agent Script', sortable: true },
          { field: 'brokerCode', header: 'Broker Code', sortable: true },
          { field: 'companyId', header: 'Company Id', sortable: true },
          { field: 'isAllWomen', header: 'AllWomen', sortable: true },
          { field: 'isFuneral', header: 'Funeral', sortable: true },
          { field: 'isOnePlan', header: 'OnePlan', sortable: true },
          { field: 'usePodSystem', header: 'UsePodSystem', sortable: true },
          { field: 'useEpodSystem', header: 'UseEpodSystem', sortable: true }
        ],
        actionsTemplate: this.actionsTemplate,
        enableSearch: true,
        enableFilters: true,
      };
    });
  }

  ngOnInit() {
    this.getVdnsByQuery();
  }

  getVdnsByQuery() {
    this.vdnQueryFilter = {contactStoreId: this.contactStoreId}
    this.vdnService
      .getVdnsByQuery(this.vdnQueryFilter)
      .subscribe((vdnResponse) => {
        if (vdnResponse) {
          this.vdnDto = vdnResponse;
        }
      });
  }

  ngOnDestroy() {
    this.subscription?.unsubscribe();
  }
}