import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ContactstoreComponent } from './contact-store.component';

describe('ContactstoreComponent', () => {
  let component: ContactstoreComponent;
  let fixture: ComponentFixture<ContactstoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContactstoreComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ContactstoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
