import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateContactStoreComponent } from './update-contact-store.component';

describe('UpdateContactStoreComponent', () => {
  let component: UpdateContactStoreComponent;
  let fixture: ComponentFixture<UpdateContactStoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [UpdateContactStoreComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdateContactStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
