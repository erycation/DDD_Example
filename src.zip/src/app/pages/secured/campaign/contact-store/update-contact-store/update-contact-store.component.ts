import { VdnService } from './../../../../../services/settings-crud/vdn/vdn.service';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { CommonModule } from '@angular/common';
import { MatGridListModule } from '@angular/material/grid-list';
import { ContactStoreService } from '../../../../../services/settings-crud/contact-store/contact-store.service';
import { TihGenericDropdownComponent } from '../../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { VdnDto } from '../../../../../models/settings-crud/vdns/vdn-dto';
import { TihGenericToggleComponent } from '../../../../components/tih-generic-toggle/tih-generic-toggle.component';
import { TihGenericInputComponent } from '../../../../components/tih-generic-input/tih-generic-input.component';
import { ContactStoreUpdateDto } from '../../../../../models/settings-crud/contact-stores/contact-store-update-dto';
import { ConnexContactPriorityUpdateDto } from '../../../../../models/settings-crud/connex-priorities/connex-contact-priority-update-dto';
import { ContactStoreDto } from '../../../../../models/settings-crud/contact-stores/contact-store-dto';
import { ResponseApi } from '../../../../../models/cdm-portal/response-api.model';
import { ContactStoreContextService } from '../../../../../services/settings-crud/contact-store/contact-store-context.service';
import { ToastService } from '../../../../../services/cdm-portal/notification/toast.service';

@Component({
  selector: 'app-update-contact-store',
  standalone: true,
  imports: [
    MatDividerModule,
    CommonModule, TihGenericDropdownComponent,
    MatGridListModule, TihGenericButtonComponent, TihGenericToggleComponent,
    TihGenericInputComponent
  ],
  templateUrl: './update-contact-store.component.html',
  styleUrl: './update-contact-store.component.scss'
})

export class UpdateContactStoreComponent {
  public contactStoreFormGroup: FormGroup = new FormGroup({});
  public bulkPriorityOptions: number[] = Array.from({ length: 50 }, (_, i) => i);
  public singlePriorityOptions: number[] = Array.from({ length: 50 }, (_, i) => 50 + i);
  public wapVdns = [] as VdnDto[];
  public updatedContactStore: ResponseApi<ContactStoreDto> = {} as ResponseApi<ContactStoreDto>;
  public contactStore: ContactStoreDto | undefined;
  public contactStoreLookups: Record<string, Array<any>> = {};

  private contactStoreId: number = 0;
  private formBuilder = inject(FormBuilder);
  private contactStoreService = inject(ContactStoreService);
  private vdnService = inject(VdnService);
  private contactStoreContextService = inject(ContactStoreContextService);
  private toastService = inject(ToastService);

  ngOnInit(){
    this.getContactStore();
    this.setupForm();
    this.getWapVdns();
  }

  getContactStore(){
    this.contactStoreId = this.contactStoreContextService.getContactStoreId();
    if(this.contactStoreId != 0){
      this.contactStore = this.contactStoreContextService.getContactStore(this.contactStoreId);
      this.contactStoreLookups = this.contactStoreContextService.getContactStoreLookups();
    }
  }

  setupForm(){
    if(!this.contactStore) return;
    
    this.contactStoreFormGroup = this.formBuilder?.group({
      shortCode: new FormControl(this.contactStore?.shortCodeId, Validators.required),
      contactOrigin: new FormControl(this.contactStore?.contactOriginId, Validators.required),
      transferDestination: new FormControl(this.contactStore?.transferDestinationId, Validators.required),
      campaignType: new FormControl(this.contactStore?.campaignTypeId, Validators.required),
      wapDestinationVdn: new FormControl(this.contactStore?.wapDestinationVdn),
      wapCloseContactInterval: new FormControl(this.contactStore?.wapCloseContactInterval ?? 0, Validators.required),
      isWapStore: new FormControl(this.contactStore?.isWapStore),
      connexContactPriorities: new FormGroup({
        priorityBulk: new FormControl(this.contactStore?.connexContactPriorities?.priorityBulk, Validators.required),
        prioritySingle: new FormControl(this.contactStore?.connexContactPriorities?.prioritySingle, Validators.required)
      })
    });
  }

  getWapVdns(){
    if(this.contactStoreId == 0) return;
    this.vdnService.getWapDestinationVdns(this.contactStoreId).subscribe(
      (vdnsResponse) => {
        this.wapVdns = vdnsResponse;
      }
    );
  }
  
  saveContactStore() {
    if(this.contactStoreId == 0) return;
    var finalWapCloseInterval = this.contactStoreFormGroup.get('wapCloseContactInterval')?.value > 0 ?
      this.contactStoreFormGroup.get('wapCloseContactInterval')?.value : 0;

    var connexContactPriorities: ConnexContactPriorityUpdateDto = {
      priorityBulk: this.contactStoreFormGroup.get('connexContactPriorities.priorityBulk')?.value,
      prioritySingle: this.contactStoreFormGroup.get('connexContactPriorities.prioritySingle')?.value
    };

    var updateDto: ContactStoreUpdateDto = {
      shortCodeId: this.contactStoreFormGroup.get('shortCode')?.value,
      campaignTypeId: this.contactStoreFormGroup.get('campaignType')?.value,
      contactOriginId: this.contactStoreFormGroup.get('contactOrigin')?.value,
      transferDestinationId: this.contactStoreFormGroup.get('transferDestination')?.value,
      connexContactPriorities: connexContactPriorities,
      wapCloseContactInterval: finalWapCloseInterval,
      isWapStore: this.contactStoreFormGroup.get('isWapStore')?.value,
      wapDestinationVdn: this.contactStoreFormGroup.get('wapDestinationVdn')?.value
    }

    this.contactStoreService.updateContactStore(this.contactStoreId, updateDto).subscribe(
      (updateResponse) => {
        this.contactStore = updateResponse.data;
        this.contactStoreContextService.addContactStores(this.contactStore);
        this.toastService.success(updateResponse.message);
      }
    );
  }

  toggleIsWapStore(){
    this.contactStoreFormGroup.get('isWapStore')?.setValue(!this.contactStoreFormGroup.get('isWapStore')?.value)
  }
}
  