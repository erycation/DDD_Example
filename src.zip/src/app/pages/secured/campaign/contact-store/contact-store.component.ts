import { CommonModule } from '@angular/common';
import { Component, inject, TemplateRef, ViewChild } from '@angular/core';
import { ContactStoreDto } from '../../../../models/settings-crud/contact-stores/contact-store-dto';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactStoreService } from '../../../../services/settings-crud/contact-store/contact-store.service';
import { TableConfig } from '../../../components/data-table/data-table.types';
import { DataTableComponent } from '../../../components/data-table/data-table.component';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { ContactStoreQueryFilterDto } from '../../../../models/settings-crud/contact-stores/contact-store-query-filter.dto';
import { ContactStoreUpdateDto } from '../../../../models/settings-crud/contact-stores/contact-store-update-dto';
import { ToastService } from '../../../../services/cdm-portal/notification/toast.service';
import { LookupService } from '../../../../services/settings-crud/lookups/lookups.service';
import { LookupDto } from '../../../../models/settings-crud/lookups/lookup-dto';
import { ContactStoreContextService } from '../../../../services/settings-crud/contact-store/contact-store-context.service';

@Component({
  selector: 'app-contactstore',
  standalone: true,
  imports: [CommonModule, DataTableComponent, TihGenericButtonComponent],
  templateUrl: './contact-store.component.html',
  styleUrl: './contact-store.component.scss'
})

export class ContactstoreComponent {
  public contactStoreDtos: ContactStoreDto[] = [];
  public contactStoreTableConfig: TableConfig = {} as TableConfig;
  public contactStoreLookups: Record<string, Array<LookupDto>> = {};

  private contactStoreService = inject(ContactStoreService);
  private activatedRoute = inject(ActivatedRoute);
  private toastService = inject(ToastService);
  private lookupService = inject(LookupService);
  private router = inject(Router); 
  private contactStoreContextService = inject(ContactStoreContextService);

  @ViewChild('actions') actionsTemplate!: TemplateRef<HTMLElement>;

  ngAfterViewInit() {
    this.contactStoreTableConfig = {
      columns: [
        { field: 'contactStoreName', header: 'Contact Store Name', sortable: true },
        { field: 'connexContactPriorities.priorityBulk', header: 'Connex Bulk Priority', sortable: true },
        { field: 'connexContactPriorities.prioritySingle', header: 'Connex Single Priority', sortable: true },
        { field: 'isActive', header: 'Enabled' }
      ],
      actionsTemplate: this.actionsTemplate,
      enableSearch: true,
      enableFilters: true,
      toggleFields: ['isActive'],
      onToggleChange: (updateRow) => this.toggleActiveStatus(updateRow)
    };
  }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      const campaignId = params.get('campaignId');

      if (campaignId) {
        const contactStoreQuery: ContactStoreQueryFilterDto = { campaignId: campaignId };
        this.contactStoreService.getContactStoresByQuery(contactStoreQuery).subscribe(
          (contactStoreResponse) => {
            this.contactStoreDtos = contactStoreResponse;
          }
        );

        this.lookupService.getLookupsBySystemName("ContactStore").subscribe(
          (lookupResponse) => {
            Object.entries(lookupResponse).forEach(([key, value]) => {
              this.contactStoreLookups[key] = value.filter(lookup => lookup.isActive);
            });
          }
        );
      }
    });
  }

  toggleActiveStatus(contactStoreDto: ContactStoreDto): void {
    if(contactStoreDto && contactStoreDto.id) {
      var contactStoreUpdateDto = { isActive: contactStoreDto.isActive } as ContactStoreUpdateDto;
      this.contactStoreService.updateContactStore(contactStoreDto.id, contactStoreUpdateDto).subscribe(
        (updateContactStoreResponse) => {
          this.toastService.success(updateContactStoreResponse.message);
        }
      );
    }
  }

  editContactStore(contactStoreUpdateData: ContactStoreDto) {
    this.contactStoreContextService.addContactStores(contactStoreUpdateData);
    this.router.navigate(['contactstore-edit', contactStoreUpdateData.id]);    
  }
}
