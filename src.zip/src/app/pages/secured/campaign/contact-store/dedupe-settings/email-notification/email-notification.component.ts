import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { TihGenericInputComponent } from '../../../../../components/tih-generic-input/tih-generic-input.component';
import { TihGenericButtonComponent } from '../../../../../components/tih-generic-button/tih-generic-button.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-email-notification',
  standalone: true,
  imports: [CommonModule, TihGenericInputComponent, TihGenericButtonComponent],
  templateUrl: './email-notification.component.html',
  styleUrl: './email-notification.component.scss'
})
export class EmailNotificationComponent {
  @Input() emailRecipients: string = "";
  @Input() id: string = "";
  @Output() emailRecipientsChange = new EventEmitter<string>();

  formBuilder = inject(FormBuilder);
  emailForm: FormGroup = new FormGroup({});

  recipients: string = "";

  ngOnInit() {
    this.recipients = this.emailRecipients;
    this.setupForm();
  }

  setupForm(){
    this.emailForm = this.formBuilder.group({
      emailAddress: new FormControl("", Validators.email)
    });
  }

  addEmail(): void {
    var emailAddressControl = this.emailForm.get("emailAddress");
    this.recipients = this.recipients === "" ? emailAddressControl?.value : this.recipients + ";" + emailAddressControl?.value;
    
    (document.getElementById(this.id) as any).value = "";
    emailAddressControl?.setValue("");
    emailAddressControl?.updateValueAndValidity();

    this.emailRecipientsChange.emit(this.recipients);
  }

  removeEmail(email: string): void {
    this.recipients = this.recipients.split(";").filter((x: string) => x !== email).join(";");
    this.emailRecipientsChange.emit(this.recipients);
  }

  isInValidEmail(): boolean {
    const emailControl = this.emailForm.get("emailAddress");
    return emailControl?.invalid || emailControl?.value === "";
  }
}
