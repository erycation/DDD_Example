import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DedupeSettingsComponent } from './dedupe-settings.component';

describe('DedupeSettingsComponent', () => {
  let component: DedupeSettingsComponent;
  let fixture: ComponentFixture<DedupeSettingsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DedupeSettingsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DedupeSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
