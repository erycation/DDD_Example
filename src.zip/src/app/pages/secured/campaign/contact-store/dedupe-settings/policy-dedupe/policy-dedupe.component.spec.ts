import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyDedupeComponent } from './policy-dedupe.component';

describe('PolicyDedupeComponent', () => {
  let component: PolicyDedupeComponent;
  let fixture: ComponentFixture<PolicyDedupeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PolicyDedupeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PolicyDedupeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
