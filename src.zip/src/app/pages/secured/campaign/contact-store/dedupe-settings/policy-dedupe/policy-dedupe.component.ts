import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { EmailNotificationComponent } from '../email-notification/email-notification.component';
import { MatCardModule } from '@angular/material/card';
import { CommonModule } from '@angular/common';
import { TihGenericCheckboxComponent } from '../../../../../components/tih-generic-checkbox/tih-generic-checkbox.component';
import { TihGenericInputAutocompleteComponent } from '../../../../../components/tih-generic-input/auto-complete/tih-generic-input-autocomplete.component';
import { TihGenericDropdownComponent } from '../../../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { LookupDto } from '../../../../../../models/settings-crud/lookups/lookup-dto';
import { FormBuilder, FormGroup } from '@angular/forms';
import { VdnService } from '../../../../../../services/settings-crud/vdn/vdn.service';
import { VdnQueryFilter } from '../../../../../../models/settings-crud/vdns/vdn-query-filter';

@Component({
  selector: 'app-policy-dedupe',
  standalone: true,
  imports: [
    CommonModule, MatCardModule, EmailNotificationComponent,
    TihGenericCheckboxComponent, TihGenericInputAutocompleteComponent,
    TihGenericDropdownComponent
  ],
  templateUrl: './policy-dedupe.component.html',
  styleUrl: './policy-dedupe.component.scss'
})
export class PolicyDedupeComponent {
  @Input() lookupDictionary: Record<string, Array<LookupDto>> = {} as Record<string, Array<LookupDto>>;
  @Input() dedupeLabel: string = "";
  @Input() dedupeTypeLabel: string = "";
  @Input() dedupeType: number = 0;
  @Input() riskTypeLabel: string = "";
  @Input() riskType: number = 0;
  @Input() sendNotification: boolean = false;
  @Input() redirect: boolean = false;
  @Input() redirectVdn: string = "";
  @Input() emailComponentElementId: string = "";
  @Input() notificationRecipients: string = "";
  @Input() vdnOptions: string[] = [];
  
  @Output() dedupeTypeChange: EventEmitter<number> = new EventEmitter<number>();
  @Output() riskTypeChange: EventEmitter<number> = new EventEmitter<number>();
  @Output() sendNotificationChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() redirectChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() redirectVdnChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() notificationRecipientsChange: EventEmitter<string> = new EventEmitter<string>();

  isEmailNotificationValid: boolean = true;
  isRedirectVdnValid: boolean = true;
  showNotification: boolean = false;
  policyDedupeForm: FormGroup = new FormGroup({});

  formBuilder = inject(FormBuilder);
  vdnService = inject(VdnService);

  ngOnChanges(): void {
    this.setupForm();
    this.showNotification = (this.lookupDictionary['DT']
      .find(x => x.id === this.dedupeType)?.name?.toLowerCase()) !== "off";
  }

  private setupForm(): void {
    this.policyDedupeForm = this.formBuilder.group({
      dedupeTypeControl: [this.dedupeType],
      riskTypeControl: [this.riskType],
      sendNotificationControl: [this.sendNotification],
      redirectControl: [this.redirect],
      redirectVdnControl: [this.redirectVdn],
      notificationRecipientsControl: [this.notificationRecipients]
    });

    if(this.sendNotification && this.notificationRecipients === "") {
      this.isEmailNotificationValid = false;
    }

    if(this.redirect && this.redirectVdn === "") {
      this.isRedirectVdnValid = false;
    }
  }

  selectedDedupeType(event: number){
    var selectedOption = this.lookupDictionary['DT'].find(x => x.id === event)?.name?.toLowerCase();
    this.showNotification = selectedOption !== "off";
    this.policyDedupeForm.get('dedupeTypeControl')?.setValue(event);

    if(selectedOption === "off"){
      var riskOff = this.lookupDictionary['DR'].find(x => x.name?.toLowerCase() === "off")?.id
      this.policyDedupeForm.get('riskTypeControl')?.setValue(riskOff);
      this.riskTypeChange.emit(riskOff);
    }
      
    this.dedupeTypeChange.emit(event);
  }

  selectedRiskType(event: number){
    this.policyDedupeForm.get('riskTypeControl')?.setValue(event);
    this.riskTypeChange.emit(event);
  }

  sendNotificationOnClick(event: boolean) {
    this.policyDedupeForm.get('sendNotificationControl')?.setValue(event);
    this.sendNotificationChange.emit(event);
  }

  recipientsChange(event: string){
    if(event === "")
      this.sendNotificationChange.emit(false);

    this.policyDedupeForm.get('notificationRecipientsControl')?.setValue(event);
    this.notificationRecipientsChange.emit(event);
  }

  redirectOnClick(event: boolean) {
    this.policyDedupeForm.get('redirectControl')?.setValue(event);
    this.redirectChange.emit(event);

    if(this.policyDedupeForm.get('redirectControl')?.value && this.vdnOptions.length === 0) {
      this.getVdns();
    }
  }

  getVdns(): void{
    var queryParameters: VdnQueryFilter = {
      isActive: true
    }

    this.vdnService.getVdnsByQuery(queryParameters).subscribe(vdnResponse => {
      var vdns = vdnResponse.map((vdn) => vdn.vdnNo) as string[];
      this.vdnOptions = [...new Set(vdns)];
    });
  }

  selectedVdn(event: string) {
    this.policyDedupeForm.get('redirectVdnControl')?.setValue(event);
    this.redirectVdnChange.emit(event);
  }
}
