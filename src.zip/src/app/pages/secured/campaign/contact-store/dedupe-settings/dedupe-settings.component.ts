import { Component, inject } from '@angular/core';
import { TihGenericInputComponent } from '../../../../components/tih-generic-input/tih-generic-input.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { LookupDto } from '../../../../../models/settings-crud/lookups/lookup-dto';
import { DedupeSettingsService } from '../../../../../services/settings-crud/dedupe-settings-service/dedupe-settings-service';
import { TihGenericDropdownComponent } from '../../../../components/tih-generic-dropdown/tih-generic-dropdown.component';
import { MatDividerModule } from '@angular/material/divider';
import { TihGenericCheckboxComponent } from '../../../../components/tih-generic-checkbox/tih-generic-checkbox.component';
import { TihGenericButtonComponent } from '../../../../components/tih-generic-button/tih-generic-button.component';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { VdnService } from '../../../../../services/settings-crud/vdn/vdn.service';
import { VdnQueryFilter } from '../../../../../models/settings-crud/vdns/vdn-query-filter';
import { DedupeSettingAddDto } from '../../../../../models/settings-crud/dedupe-settings/dedupe-setting-add-dto';
import { DedupeSettingUpdateDto } from '../../../../../models/settings-crud/dedupe-settings/dedupe-setting-update-dto';
import { PolicyDedupeComponent } from './policy-dedupe/policy-dedupe.component';
import { ContactStoreContextService } from '../../../../../services/settings-crud/contact-store/contact-store-context.service';
import { ToastService } from '../../../../../services/cdm-portal/notification/toast.service';

@Component({
  selector: 'app-dedupe-settings',
  standalone: true,
  imports: [TihGenericInputComponent, TihGenericDropdownComponent, MatDividerModule,
    TihGenericCheckboxComponent, TihGenericButtonComponent,
    CommonModule, MatCardModule, PolicyDedupeComponent
  ],
  templateUrl: './dedupe-settings.component.html',
  styleUrl: './dedupe-settings.component.scss'
})

export class DedupeSettingsComponent {
  public dedupeSettingsFormGroup: FormGroup = new FormGroup({});
  public emailForm: FormGroup = new FormGroup({});
  public vdnOptions: string[] = [];
  public showActiveNotification: boolean = false;
  public showInactiveNotification: boolean = false;
  public dedupeSettingsId: number | undefined;
  public formValid: boolean = false;
  public offDedupeTypeId: number | undefined;
  public offRiskTypeId: number | undefined;
  public offDedupeLevelId: number | undefined;
  public contactStoreId: number = 0;
  public lookupDictionary: Record<string, Array<LookupDto>> = {};

  private formBuilder = inject(FormBuilder);
  private dedupeSettingsService = inject(DedupeSettingsService);
  private vdnService = inject(VdnService);
  private contactStoreContextService = inject(ContactStoreContextService);
  private toastService = inject(ToastService);

  ngOnInit(): void {
    this.contactStoreId = this.contactStoreContextService.getContactStoreId();
    this.lookupDictionary = this.contactStoreContextService.getContactStoreLookups();
    this.setupForm();
    this.getDedupeSettingsByContactStoreId();
  }

  setupForm(): void {
    this.offDedupeTypeId = this.lookupDictionary['DT'].find(x => x.name?.toLowerCase() === "off")?.id;
    this.offRiskTypeId = this.lookupDictionary['DR'].find(x => x.name?.toLowerCase() === "off")?.id;
    this.offDedupeLevelId = this.lookupDictionary['DL'].find(x => x.name?.toLowerCase() === "off")?.id;

    this.emailForm = this.formBuilder.group({
      activeEmailAddress: new FormControl("", Validators.email),
      inactiveEmailAddress: new FormControl("", Validators.email)
    });

    this.dedupeSettingsFormGroup = this.formBuilder?.group({
      inboundDedupeLevelId: new FormControl(this.offDedupeLevelId),
      inboundDedupeDays: new FormControl(0),
      outboundDedupeLevelId: new FormControl(this.offDedupeLevelId),
      outboundDedupeDays: new FormControl(0),
      activeTypeId: new FormControl(this.offDedupeTypeId),
      inactiveTypeId: new FormControl(this.offDedupeTypeId),
      activeRiskId: new FormControl(this.offRiskTypeId),
      inactiveRiskId: new FormControl(this.offRiskTypeId),
      optOut: new FormControl(false),
      activeSendNotification: new FormControl(false),
      activeNotificationRecipients: new FormControl(""),
      activeRedirectToCampaign: new FormControl(false),
      activeCampaignUrl: new FormControl(""),
      inactiveSendNotification: new FormControl(false),
      inactiveNotificationRecipients: new FormControl(""),
      inactiveRedirectToCampaign: new FormControl(false),
      inactiveCampaignUrl: new FormControl("")
    });

    this.formValidators();
  }

  formValidators(): void{
    var inboundDedupeDaysControl = this.dedupeSettingsFormGroup.get('inboundDedupeDays');
    var outboundDedupeDaysControl = this.dedupeSettingsFormGroup.get('outboundDedupeDays');

    this.dedupeSettingsFormGroup.get('inboundDedupeLevelId')?.valueChanges.subscribe(value => {
      if(this.lookupDictionary['DL'].find(x => x.id === value)?.name?.toLowerCase() !== "off"){
        inboundDedupeDaysControl?.setValidators(Validators.required)
      }else{
        inboundDedupeDaysControl?.clearValidators();
        this.dedupeSettingsFormGroup.get('inboundDedupeDays')?.setValue(0);
      }
      inboundDedupeDaysControl?.updateValueAndValidity();
    });

    this.dedupeSettingsFormGroup.get('outboundDedupeLevelId')?.valueChanges.subscribe(value => {
      if(this.lookupDictionary['DL'].find(x => x.id === value)?.name?.toLowerCase() !== "off"){
        outboundDedupeDaysControl?.setValidators(Validators.required)
      }else{
        outboundDedupeDaysControl?.clearValidators();
        this.dedupeSettingsFormGroup.get('outboundDedupeDays')?.setValue(0);
      }
      outboundDedupeDaysControl?.updateValueAndValidity();
    });
  }

  getDedupeSettingsByContactStoreId(): void {
    this.dedupeSettingsService.getDedupeSettingsByContactStoreId(this.contactStoreId)
      .subscribe(dedupeSettingResponse =>{
        if(dedupeSettingResponse){
          var dedupeSettings = dedupeSettingResponse[0];
          this.dedupeSettingsFormGroup.patchValue({
            inboundDedupeLevelId: dedupeSettings.inboundDedupeLevelId,
            inboundDedupeDays: dedupeSettings.inboundDedupeDays,
            outboundDedupeLevelId: dedupeSettings.outboundDedupeLevelId,
            outboundDedupeDays: dedupeSettings.outboundDedupeDays,
            activeTypeId: dedupeSettings.activeTypeId,
            inactiveTypeId: dedupeSettings.inactiveTypeId,
            activeRiskId: dedupeSettings.activeRiskId,
            inactiveRiskId: dedupeSettings.inactiveRiskId,
            optOut: dedupeSettings.optOut,
            activeSendNotification: dedupeSettings.activeSendNotification,
            activeNotificationRecipients: dedupeSettings.activeNotificationRecipients,
            activeRedirectToCampaign: dedupeSettings.activeRedirectToCampaign,
            activeCampaignUrl: dedupeSettings.activeCampaignUrl,
            inactiveSendNotification: dedupeSettings.inactiveSendNotification,
            inactiveNotificationRecipients: dedupeSettings.inactiveNotificationRecipients,
            inactiveRedirectToCampaign: dedupeSettings.inactiveRedirectToCampaign,
            inactiveCampaignUrl: dedupeSettings.inactiveCampaignUrl
          });

          this.dedupeSettingsId = dedupeSettings.id;
          this.showActiveNotification = (this.lookupDictionary['DT']
              .find(x => x.id === dedupeSettings.activeTypeId)?.name?.toLowerCase()) !== "off";
          this.showInactiveNotification = (this.lookupDictionary['DT']
              .find(x => x.id === dedupeSettings.inactiveTypeId)?.name?.toLowerCase()) !== "off";

          if(dedupeSettings.activeRedirectToCampaign || dedupeSettings.inactiveRedirectToCampaign) {
            this.getVdns();
          }
        }
      });
  }

  getVdns(): void{
    var queryParameters: VdnQueryFilter = {
      isActive: true
    }

    this.vdnService.getVdnsByQuery(queryParameters).subscribe(vdnResponse => {
      var vdns = vdnResponse.map((vdn) => vdn.vdnNo) as string[];
      this.vdnOptions = [...new Set(vdns)];
    });
  }

  saveDedupeSettings(): void{
    if(this.dedupeSettingsId === undefined){
      var dedupeSettingsAdd = this.dedupeSettingsFormGroup.value as DedupeSettingAddDto;
      dedupeSettingsAdd.contactStoreId = this.contactStoreId;
      this.dedupeSettingsService.addDedupeSettings(dedupeSettingsAdd)
        .subscribe(addResponse =>{
          this.toastService.success(addResponse.message);
        });
      
    }else{
      var dedupeSettingsUpdate = this.dedupeSettingsFormGroup.value as DedupeSettingUpdateDto;
      this.dedupeSettingsService.updateDedupeSettings(this.dedupeSettingsId, dedupeSettingsUpdate)
        .subscribe(updateResponse =>{
          this.toastService.success(updateResponse.message);
        });
    }
  }
}
