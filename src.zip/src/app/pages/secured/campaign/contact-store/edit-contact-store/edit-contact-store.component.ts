import { Component, inject } from '@angular/core';
import { TabNavComponent } from '../../../../components/tab-nav/tab-nav.component';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { ContactStoreContextService } from '../../../../../services/settings-crud/contact-store/contact-store-context.service';
import { LookupService } from '../../../../../services/settings-crud/lookups/lookups.service';
import { ContactStoreService } from '../../../../../services/settings-crud/contact-store/contact-store.service';

@Component({
  selector: 'app-edit-contact-store',
  standalone: true,
  imports: [TabNavComponent, RouterModule],
  templateUrl: './edit-contact-store.component.html',
  styleUrl: './edit-contact-store.component.scss'
})
export class EditContactStoreComponent {
  stepTabs = [
    { label: 'ContactStore Settings', route: './' },
    { label: 'Dedupe Settings', route: 'dedupe-settings' },
    { label: 'Vdn Settings', route: 'vdn-settings' },
    { label: 'Sms Settings', route: 'sms-settings' }
  ];

  private contactStoreContextService = inject(ContactStoreContextService);
  private activatedRoute = inject(ActivatedRoute);
  private lookupService = inject(LookupService);
  private contactStoreService = inject(ContactStoreService);
  public contactStoreName = "";

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      const contactStoreId = params.get('contactStoreId');
      if (contactStoreId) {
        this.contactStoreContextService.addContactStoreId(parseInt(contactStoreId));

        this.contactStoreContextService.contactStores$.subscribe(contactStores => {
          let contactStore = contactStores.find(store => store.id === parseInt(contactStoreId));
          if(!contactStore){
            this.contactStoreService.getContactStore(parseInt(contactStoreId)).subscribe(
              (contactStoreResponse) => {
                this.contactStoreContextService.addContactStores(contactStoreResponse);
                contactStore = contactStoreResponse;
              }
            );
          }
          this.contactStoreName = contactStore?.contactStoreName ?? "";
        });
      }
    });

    this.getLookupDictionary();
  }
  
  getLookupDictionary(): void {
    const lookupDictionary = this.contactStoreContextService.getContactStoreLookups();
    if(Object.keys(lookupDictionary).length === 0) {
      this.lookupService.getLookupsBySystemName("ContactStore").subscribe(
        (lookupResponse) => {
          this.contactStoreContextService.addContactStoreLookups(lookupResponse);
        }
      );
    }
  }
}
