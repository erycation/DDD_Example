import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditContactStoreComponent } from './edit-contact-store.component';

describe('EditContactStoreComponent', () => {
  let component: EditContactStoreComponent;
  let fixture: ComponentFixture<EditContactStoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditContactStoreComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditContactStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
