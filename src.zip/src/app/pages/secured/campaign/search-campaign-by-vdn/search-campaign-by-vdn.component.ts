import { Component, inject } from '@angular/core';
import { FormGroup, FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { TihGenericInputComponent } from '../../../components/tih-generic-input/tih-generic-input.component';
import { CampaignService } from '../../../../services/settings-crud/campaign/campaign.service';
import { VdnService } from '../../../../services/settings-crud/vdn/vdn.service';
import { TihGenericAutoCompleteComponent } from '../../../components/tih-generic-dropdown/auto-complete/tih-generic-autocomplete.component';
import { VdnDto } from '../../../../models/settings-crud/vdns/vdn-dto';
import { MatFormFieldModule } from '@angular/material/form-field';
import { TihGenericButtonComponent } from '../../../components/tih-generic-button/tih-generic-button.component';
import { CommonModule } from '@angular/common';
import { CampaignDetailDto } from '../../../../models/settings-crud/campaigns/campaign-detail-dto';
import { Router } from '@angular/router';

@Component({
  selector: 'search-campaign-by-vdn',
  standalone: true,
  imports: [
    TihGenericInputComponent,
    TihGenericAutoCompleteComponent,
    TihGenericButtonComponent,
    CommonModule,
    MatDialogModule,
    MatFormFieldModule,
    ReactiveFormsModule
  ],
  templateUrl: './search-campaign-by-vdn.component.html',
  styleUrl: './search-campaign-by-vdn.component.scss'
})
export class SearchCampaignByVdnComponent {

  vdnFormGroup!: FormGroup;
  vdnList: VdnDto[] = [];
  selectedVdn: VdnDto | null = null;
  showCampaign: boolean = false;
  campaignDetails: CampaignDetailDto | undefined

  public campaignService = inject(CampaignService);
  public vdnService = inject(VdnService);
  public dialogRef = inject(MatDialogRef<SearchCampaignByVdnComponent>);
  private router = inject(Router);

  ngOnInit() {
    this.vdnFormGroup = new FormGroup({});

    this.vdnService.getVdns().subscribe(vdnResult => {
      this.vdnList = vdnResult;
    });
  }

  vdnDisplay = (vdn: VdnDto) => `${vdn.vdnNo?.trim()} - ${vdn.brokerCode?.trim()}`;

  setVdnBrokers(vdn: VdnDto): void {
    this.selectedVdn = vdn;
  }

  search(): void {
    this.campaignService.getCampaignByVdn(this.selectedVdn?.vdnNo!).subscribe(data => {
        if (data) {
          this.campaignDetails = data;
          this.showCampaign = true
        }
      });
  }

    openSource() {
      this.router.navigate(['/contactstore/', this.campaignDetails!.campaignId, 'campaign']);
      this.dialogRef.close();
    }
}
