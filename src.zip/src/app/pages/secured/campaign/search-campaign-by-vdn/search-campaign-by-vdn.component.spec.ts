import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchCampaignByVdnComponent } from './search-campaign-by-vdn.component';


describe('SearchCampaignByVdnComponent', () => {
  let component: SearchCampaignByVdnComponent;
  let fixture: ComponentFixture<SearchCampaignByVdnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchCampaignByVdnComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchCampaignByVdnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
