import { Component, ViewChild, TemplateRef, AfterViewInit, inject } from '@angular/core';
import { TableConfig } from '../../components/data-table/data-table.types';
import { CommonModule } from '@angular/common';
import { DataTableComponent } from '../../components/data-table/data-table.component';
import { CampaignDto } from '../../../models/settings-crud/campaigns/campaign-dto';
import { CampaignService } from '../../../services/settings-crud/campaign/campaign.service';
import { MatDialog } from '@angular/material/dialog';
import { UpdateCampaignComponent } from './update-campaign/update-campaign.component';
import { CampaignUpdateDto } from '../../../models/settings-crud/campaigns/campaign-update-dto';
import { TihGenericButtonComponent } from '../../components/tih-generic-button/tih-generic-button.component';
import { UpdateData } from '../../../models/cdm-portal/utilities/updateData';
import { ToastService } from '../../../services/cdm-portal/notification/toast.service';
import { Router } from '@angular/router';
import { SearchCampaignByVdnComponent } from './search-campaign-by-vdn/search-campaign-by-vdn.component';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';

@Component({
 selector: 'app-campaign',
  standalone: true,
  imports: [CommonModule, DataTableComponent, TihGenericButtonComponent],
  templateUrl: './campaign.component.html',
  styleUrl: './campaign.component.scss'
})

export class CampaignComponent {
 campaignsDto: CampaignDto[] = [];
 campaignTableConfig!: TableConfig;

 @ViewChild('actions') actionsTemplate!: TemplateRef<any>;

  private campaignService = inject(CampaignService);
  private dialog = inject(MatDialog);
  private toast = inject(ToastService);
  private router = inject(Router);

  ngAfterViewInit(): void{
    setTimeout(() => {
      this.campaignTableConfig = {
          columns: [
            { field: 'campaignName', header: 'Camapign Name', sortable: true },
            { field: 'campaignModeDto.name', header: 'Campaign Mode', sortable: true },
            { field: 'businessFunctionDto.name', header: 'Business Unit', sortable: true },
            { field: 'businessUnitDto.name', header: 'Business Function', sortable: true },
            { field: 'sourceCount', header: 'Source Count', sortable: true },
            { field: 'isActive', header: 'Enabled' }
          ],
          actionsTemplate: this.actionsTemplate,
          enableSearch: true,
          enableFilters: true,
          toggleFields: ['isActive'],
          onToggleChange: (updateRow) => this.toggleCampaignStatus(updateRow)
        };
      });
  }

 ngOnInit(): void {
  this.campaignService.getCampaigns().subscribe(campaignsResponse => {
    if(campaignsResponse){
      this.campaignsDto = campaignsResponse
    }})
  }
  searchCampaignByVdn() {
    this.dialog.open(SearchCampaignByVdnComponent, {
      width: '800px',
      disableClose: true,
    });
  }
  
  toggleCampaignStatus(campaignDto: CampaignDto): void {
    const campaignUpdateDto: CampaignUpdateDto = { isActive: campaignDto.isActive }

    this.campaignService
      .updateCampaign(campaignDto.id!, campaignUpdateDto)
      .subscribe(updateCampaignResponse => {
        if(updateCampaignResponse){
           var index: number = this.campaignsDto.findIndex(x => x.id === updateCampaignResponse.data.id);
          this.campaignsDto[index] = updateCampaignResponse.data;
          this.toast.success(`${updateCampaignResponse.message}`); 
        }
      });
  }

  openSource(campaignDto: CampaignDto) {
    this.router.navigate(['/contactstore/', campaignDto.id, 'campaign']);
  }

  editCampaign(campaignUpdateDto: CampaignDto) {
    const campaignUpdateData: UpdateData<CampaignDto> =
    {
      title: `Update ${campaignUpdateDto.campaignName}`,
      message: '',
      modelDto: campaignUpdateDto
    }
    var dialogRef = this.dialog.open(UpdateCampaignComponent, {
      width: '800px',
      data: campaignUpdateData,
      disableClose: true,
    });

     dialogRef.afterClosed().subscribe((result: ResponseApi<CampaignDto>) => {
      if (result) {
        var index: number = this.campaignsDto.findIndex(x => x.id === result.data.id);
        this.campaignsDto[index] = result.data;
        this.toast.success(result.message);
      }
    });
  }
}
