import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TihGenericButtonComponent } from './tih-generic-button.component';


describe('TihGenericButtonComponent', () => {
  let component: TihGenericButtonComponent;
  let fixture: ComponentFixture<TihGenericButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericButtonComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TihGenericButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
