import { CommonModule } from '@angular/common';
import { Component, Input, Output, EventEmitter, forwardRef } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';

@Component({
  selector: 'tih-generic-button',
  standalone: true,
  imports: [CommonModule, MatButton, MatIcon],
  templateUrl: './tih-generic-button.component.html',
  styleUrl: './tih-generic-button.component.scss',
})
export class TihGenericButtonComponent {
  @Input() label: string = 'Click';
  @Input() icon?: string;
  @Input() type: 'primary' | 'secondary' | 'cancel' | 'danger' = 'primary';
  @Input() disabled: boolean = false;

  @Output() clicked = new EventEmitter<void>();

  handleClick() {
    if (!this.disabled) {
      this.clicked.emit();
    }
  }
}
