import { CommonModule } from '@angular/common';
import { Component, Input } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-tab-nav',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './tab-nav.component.html',
  styleUrls: ['./tab-nav.component.scss']
})
export class TabNavComponent {
  @Input() tabs: { label: string; route: string }[] = [];
}
