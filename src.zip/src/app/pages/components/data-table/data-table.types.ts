import { TemplateRef } from '@angular/core';

export interface TableColumn {
    field: string;
    header: string;
    sortable?: boolean;
    cellTemplate?: TemplateRef<any>;
}

export interface TableConfig {
    columns: TableColumn[];
    pageSizeOptions?: number[];
    actionsTemplate?: TemplateRef<any>;
    onRowClick?: (row: any) => void;
    enableSearch?: boolean;
    enableFilters?: boolean;
    toggleFields?: string[];
    onToggleChange?: (row: any) => void;
}