import { Component, Input, Output, EventEmitter, TemplateRef } from '@angular/core';
import { TableConfig } from './data-table.types';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
 selector: 'app-data-table',
 standalone: true,
 imports: [CommonModule, FormsModule],
 templateUrl: './data-table.component.html',
 styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent {
  @Input() data: any[] = [];
  @Input() config!: TableConfig;
  @Output() edit = new EventEmitter<any>();
  @Output() delete = new EventEmitter<any>();
  currentPage = 1;
  sortField = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  currentPageSize: number = 5;
  showFilters = false;
  searchTerm: string = '';
  filters: { [key: string]: string } = {};
  filteredData: any[] = []

  Math = Math;

  get pagedData() {
    const start = (this.currentPage - 1) * this.currentPageSize;
    return this.sortedData.slice(start, start + this.currentPageSize);
  }

  get totalPages(){
    return Math.ceil(this.sortedData.length / this.currentPageSize)
  }

  get sortedData() {
    let result = this.data;

    if (this.config.enableSearch && this.searchTerm.trim()) {
      const term = this.searchTerm.trim().toLowerCase();
      result = result.filter(row =>
        this.config.columns.some(col => String(row[col.field]).toLowerCase().includes(term))
      );
    }

    if (this.config.enableFilters) {
      Object.entries(this.filters).forEach(([field, value]) => {
        if (value) {
          result = result.filter(row => String(this.getCallValue(row, field)) === value);
        }
      });
    }
    
    if (this.sortField) {
      result = [...result].sort((a, b) => {
        const aVal = a[this.sortField];
        const bVal = b[this.sortField];
        return this.sortDirection === 'asc'
          ? aVal > bVal ? 1 : -1
          : aVal < bVal ? 1 : -1;
      });
    }
    return result;
  }

  toggleFilters = () => this.showFilters = !this.showFilters;

  getUniqueValues(field: string): string[] {
    const values = this.data.map(row => this.getCallValue(row, field));
    return Array.from(new Set(values));
  }
  
 sort(field: string) {
    if (this.sortField === field) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortField = field;
      this.sortDirection = 'asc';
    }
  }
  handleRowClick(row: any) {
    this.config.onRowClick?.(row);
  }
  
  changePageSize(){
      this.currentPage = 1;
  }

  isToggleField(field: string): boolean {
  return this.config.toggleFields?.includes(field) ?? false;
  }

  handleToggle(field: string, row: any) {
    var toUpdate = this.data.find(x => x.id === row.id);
    var index = this.data.indexOf(toUpdate);
    toUpdate[field] = !toUpdate[field];
    
    this.data[index] = toUpdate;
    const updatedRow = { ...row, [field]: toUpdate[field] };
    if (this.config.onToggleChange) {
      this.config.onToggleChange(updatedRow);
    }
  }

  getCallValue(row: any, path: string): any{
    return path.split('.').reduce((value, key) => value?.[key], row);
  }
 
 changePage(dir: 'next' | 'prev') {
   const totalPages = Math.ceil(this.data.length / (this.currentPageSize || 10));
   if (dir === 'prev' && this.currentPage > 1) this.currentPage--;
   if (dir === 'next' && this.currentPage < totalPages) this.currentPage++;
 }
}