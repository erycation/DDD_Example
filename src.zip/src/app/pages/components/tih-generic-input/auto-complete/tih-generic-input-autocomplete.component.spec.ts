import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TihGenericInputAutocompleteComponent } from './tih-generic-input-autocomplete.component';

describe('TihGenericInputAutocompleteComponent', () => {
  let component: TihGenericInputAutocompleteComponent;
  let fixture: ComponentFixture<TihGenericInputAutocompleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericInputAutocompleteComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TihGenericInputAutocompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
