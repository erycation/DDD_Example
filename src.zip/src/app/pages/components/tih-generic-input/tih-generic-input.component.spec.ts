import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TihGenericInputComponent } from './tih-generic-input.component';


describe('TihGenericInputComponent', () => {
  let component: TihGenericInputComponent;
  let fixture: ComponentFixture<TihGenericInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericInputComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TihGenericInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
