import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  selector: 'tih-generic-toggle',
  standalone: true,
  imports: [
    CommonModule,
    MatSlideToggleModule
  ],
  templateUrl: './tih-generic-toggle.component.html',
  styleUrl: './tih-generic-toggle.component.scss'
})
export class TihGenericToggleComponent {
  @Input() value: boolean = false;
  @Input() label: string = '';
  @Input() disabled: boolean = false;
  @Output() valueChange = new EventEmitter<boolean>();

  onChange(event: any): void {
    this.valueChange.emit(event.target.checked);
  }
}
