import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TihGenericToggleComponent } from './tih-generic-toggle.component';


describe('TihGenericToggleComponent', () => {
  let component: TihGenericToggleComponent;
  let fixture: ComponentFixture<TihGenericToggleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericToggleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TihGenericToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
