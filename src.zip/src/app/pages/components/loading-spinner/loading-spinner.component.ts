import { Component, inject } from '@angular/core';
import { LoadingSpinnerService } from '../../../services/cdm-portal/loading-spinner/loading-spinner.service';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AsyncPipe, NgIf } from '@angular/common';

@Component({
  selector: 'app-loading-spinner',
  standalone: true,
  imports: [MatProgressSpinnerModule,
    NgIf,
    AsyncPipe
  ],
  templateUrl: './loading-spinner.component.html',
  styleUrl: './loading-spinner.component.scss'
})
export class LoadingSpinnerComponent {

  loader = inject(LoadingSpinnerService);

}