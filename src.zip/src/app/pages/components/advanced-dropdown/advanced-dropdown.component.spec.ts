import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdvancedDropdownComponent } from './advanced-dropdown.component';

describe('AdvancedDropdownComponent', () => {
  let component: AdvancedDropdownComponent;
  let fixture: ComponentFixture<AdvancedDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdvancedDropdownComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdvancedDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
