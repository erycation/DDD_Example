import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-dropdown',
  standalone: true,
  imports: [],
  templateUrl: './advanced-dropdown.component.html',
  styleUrl: './advanced-dropdown.component.scss'
})
export class AdvancedDropdownComponent {

}
