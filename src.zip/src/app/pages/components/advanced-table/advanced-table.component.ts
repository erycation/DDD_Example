import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, OnChanges, ViewChild, model } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { DatePipe, NgIf } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Column } from '../../../models/cdm-portal/column.model';
import { ViewOptions } from '../../../models/cdm-portal/page-settings.model';

@Component({
  selector: 'tih-advanced-table',
  standalone: true,
  imports: [
    MatButtonModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    MatSortModule,
    MatTableModule,
    NgIf,
    DatePipe
  ],
  templateUrl: './advanced-table.component.html',
  styleUrl: './advanced-table.component.scss'
})
export class TIHAdvancedTableComponent implements OnInit, OnChanges, AfterViewInit {
  columnNames: string[] = [];
  columnLabels: string[] = [];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator)
  paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  @Input() pageSizeOptions: number[] = [5, 10, 25, 100];
  @Input() pageSize: number = 10;
  @Input() columns: Column[] = [];
  @Input() data: any[] = [];
  @Input() viewOptions?: ViewOptions = {
    hasPagination: true,
    isSearchable: true,
    isSortable: true,
    hasAdd: false,
    labelAddNew: 'Add New',
    actionsWidth: 176,
    hasView: true,
  };

  searchTerm = model<string>('');
  protected hasActions = false;

  @Output() addRow = new EventEmitter<any>();
  @Output() viewRow = new EventEmitter<any>();
  @Output() updateRow = new EventEmitter<any>();
  @Output() deleteRow = new EventEmitter<any>();

  ngOnInit(): void {
    this.columnLabels = this.columns.map(col => col.label);
    this.columnNames = this.columns.map(col => col.name);

    this.hasActions = (this.viewOptions?.hasView || this.viewOptions?.hasUpdate || this.viewOptions?.hasDelete) || false;
    if (this.hasActions) this.columnNames.push('actions');

    this.dataSource = new MatTableDataSource(this.data);
    this.sortAndPages();

  }

  ngOnChanges(): void {
    this.dataSource = new MatTableDataSource(this.data);
    this.sortAndPages();
  }

  ngAfterViewInit() {
    this.sortAndPages();
  }

  sortAndPages() {
    if (this.viewOptions?.hasPagination) {
      this.dataSource.paginator = this.paginator;
    }

    if (this.viewOptions?.isSortable) {
      this.dataSource.sort = this.sort;
    }
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.searchTerm.set(filterValue);
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  addAction(): void {
    //Emit -1 to inform the parent that the Add button was clicked
    this.addRow.emit(-1);
  }

  viewAction(row?: any): void {
    // Emit the data row to the parent component for viewing
    this.viewRow.emit(row);
  }

  updateAction(row?: any): void {
    // Emit the data row to the parent component for update
    this.updateRow.emit(row);
  }

  deleteAction(row?: any): void {
    // Emit the data row to the parent component for deletion
    this.deleteRow.emit(row);
  }
}
