import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TIHAdvancedTableComponent } from './advanced-table.component';

describe('AdvancedTableComponent', () => {
  let component: TIHAdvancedTableComponent;
  let fixture: ComponentFixture<TIHAdvancedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TIHAdvancedTableComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TIHAdvancedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
