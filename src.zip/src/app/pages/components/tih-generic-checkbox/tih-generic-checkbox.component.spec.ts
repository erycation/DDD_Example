import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TihGenericCheckboxComponent } from './tih-generic-checkbox.component';

describe('TihGenericCheckboxComponent', () => {
  let component: TihGenericCheckboxComponent;
  let fixture: ComponentFixture<TihGenericCheckboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericCheckboxComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TihGenericCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
