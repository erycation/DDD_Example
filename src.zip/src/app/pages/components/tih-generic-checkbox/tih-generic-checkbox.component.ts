import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatCheckboxModule } from '@angular/material/checkbox';

@Component({
  selector: 'tih-generic-checkbox',
  standalone: true,
  imports: [MatCheckboxModule],
  templateUrl: './tih-generic-checkbox.component.html',
  styleUrl: './tih-generic-checkbox.component.scss'
})
export class TihGenericCheckboxComponent {
  @Input() public label: string = "";
  @Input() public checked: boolean = false;
  @Input() public disabled: boolean = false;
  @Input() public required: boolean = false;
  @Input() public name: string = "";
  @Output() public valueChange = new EventEmitter<boolean>();

  onChange(event: any): void {
    this.valueChange.emit(event.checked);
  }
}
