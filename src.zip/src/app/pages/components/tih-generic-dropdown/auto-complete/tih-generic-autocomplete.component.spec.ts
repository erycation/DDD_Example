import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TihGenericAutoCompleteComponent } from './tih-generic-autocomplete.component';

describe('TihGenericDropdownComponent', () => {
  let component: TihGenericAutoCompleteComponent;
  let fixture: ComponentFixture<TihGenericAutoCompleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericAutoCompleteComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TihGenericAutoCompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
