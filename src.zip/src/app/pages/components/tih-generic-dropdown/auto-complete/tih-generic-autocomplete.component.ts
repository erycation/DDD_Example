import { Component, EventEmitter, input, Input, Output, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { map, Observable, startWith } from 'rxjs';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material/autocomplete';

@Component({
  selector: 'tih-generic-autocomplete',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule
  ],
  templateUrl: './tih-generic-autocomplete.component.html',
  styleUrl: './tih-generic-autocomplete.component.scss'
})
export class TihGenericAutoCompleteComponent{

  @Input() label: string | undefined;
  @Input() placeholder: string = ''
  @Input() options: any[] = [];
  @Input() idKey: string = 'id';
  @Input() required: boolean = false;
  @Input() valueKey: string = 'value';
  @Input() displayFn: (option: any) => string = (opt) => opt;
  @Output() onSelect = new EventEmitter<any>();
  
  inputControl = new FormControl();
  filteredOptions: Observable<any[]> | undefined;

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['options']) {
      this.filteredOptions = this.inputControl.valueChanges.pipe(
        startWith(''),
        map(value => this._filter(value || ''))
      );
    }
  }

  private _filter(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option =>
      this.displayFn(option).toLowerCase().includes(filterValue)
    );
  }

  handleSelect(option: any) {
    this.onSelect.emit(option);
  }
}
