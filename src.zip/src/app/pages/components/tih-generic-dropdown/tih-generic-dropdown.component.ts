import { Component, EventEmitter, input, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'tih-generic-dropdown',
  standalone: true,
  imports: [CommonModule, MatFormFieldModule, MatSelectModule, FormsModule],
  templateUrl: './tih-generic-dropdown.component.html',
  styleUrl: './tih-generic-dropdown.component.scss'
})
export class TihGenericDropdownComponent<T extends Record<string, any>> {

  @Input() label: string | undefined;
  @Input() placeholder: string = 'Select an option';
  @Input() required: boolean = false;
  @Input() disabled: boolean = false;
  @Input() value: any;
  @Input() options: any[] = [];
  @Input() valueKey: string = 'id';
  @Input() displayKey: string = 'name';
  @Output() valueChange = new EventEmitter<any>();

  onChange(value: number) {
    this.valueChange.emit(value as unknown as any);
  }
}
