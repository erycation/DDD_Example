import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TihGenericDropdownComponent } from './tih-generic-dropdown.component';

describe('TihGenericDropdownComponent', () => {
  let component: TihGenericDropdownComponent<any>;
  let fixture: ComponentFixture<TihGenericDropdownComponent<any>>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TihGenericDropdownComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TihGenericDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
