import { CommonModule } from '@angular/common';
import { Component, inject, Input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-side-menu',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIcon],
  templateUrl: './side-menu.component.html',
  styleUrl: './side-menu.component.scss'
})

export class SideMenuComponent {
  
 private router = inject(Router);

  @Input() isOpen: boolean = false;
  menuItems = [{
      label: 'Dashboard',
      route: '/',
      icon: 'dashboard',
      subItems: []
    },
    {
      label: 'Campaign Management',
      isOpen: false,
      route: '/campaign',
      icon: 'campaign',
      subItems: []
    },
    {
      label: 'Company Management',
      icon: 'apartment',
      route: '/company'
    },
    {
      label: 'SMS Template Management',
      icon: 'sms',
      route: '/sms-lookup'
    },
    {
      label: 'Brand Management',
      icon: 'branding_watermark',
      route: '/brand'
    },
    {
      label: 'Contact Management',
      isOpen: false,
      route: '/contact',
      icon: 'call',
      subItems: []
    },
    {
      label: 'Lookup Management',
      icon: 'assessment',
      isOpen: false,
      subItems: [
        { label: 'Lookup Types', route: '/lookup-types' }
      ]
    },
    {
      label: 'Report Management',
      icon: 'monitoring',
      route: '/reports',
      subItems: []
    }
  ];
  toggleSubmenu(item: any) {
    item.isOpen = !item.isOpen;
  }

  navigate(path: string) {
    this.router.navigate([path]);
  }
}
