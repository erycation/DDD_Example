import { Routes } from '@angular/router';
import { CompanyComponent } from './pages/secured/company/company.component';
import { CampaignComponent } from './pages/secured/campaign/campaign.component';
import { LookupTypeComponent } from './pages/secured/lookup-type/lookup-type.component';
import { LookupComponent } from './pages/secured/lookup-type/lookup/lookup.component';
import { ContactstoreComponent } from './pages/secured/campaign/contact-store/contact-store.component';
import { UploadContactsComponent } from './pages/secured/contact/upload-contacts/upload-contacts.component';
import { ContactLandingComponent } from './pages/secured/contact/contact-landing.component';
import { ContactComponent } from './pages/secured/contact/contacts/contact.component';
import { ContactDetailsLandingComponent } from './pages/secured/contact/contacts/contact-details/contact-details-landing.component';
import { ContactDetailsComponent } from './pages/secured/contact/contacts/contact-details/contact-details/contact-details.component';
import { PersonalDetailsComponent } from './pages/secured/contact/contacts/contact-details/personal-details/personal-details.component';
import { NotesComponent } from './pages/secured/contact/contacts/contact-details/notes/notes.component';
import { BrandComponent } from './pages/secured/brand/brand.component';
import { SmsLookupComponent } from './pages/secured/sms-lookup/sms-lookup.component';
import { TraceComponent } from './pages/secured/contact/contacts/contact-details/trace/trace.component';
import { EditContactStoreComponent } from './pages/secured/campaign/contact-store/edit-contact-store/edit-contact-store.component';
import { UpdateContactStoreComponent } from './pages/secured/campaign/contact-store/update-contact-store/update-contact-store.component';
import { DedupeSettingsComponent } from './pages/secured/campaign/contact-store/dedupe-settings/dedupe-settings.component';
import { VdnComponent } from './pages/secured/campaign/contact-store/vdn-settings/vdn.component';
import { SmsSettingsComponent } from './pages/secured/campaign/contact-store/sms-settings/sms-settings.component';
import { AddSmsSettingsComponent } from './pages/secured/campaign/contact-store/sms-settings/add-sms-settings/add-sms-settings.component';

export const routes: Routes = [
  {
    path: '',
    children: [
      { path: 'brand', component: BrandComponent },
      { path: 'sms-lookup', component: SmsLookupComponent},
      { path: 'company', component: CompanyComponent },
      { path: 'campaign', component: CampaignComponent },
      { path: 'lookup-types', component: LookupTypeComponent },
      { path: 'lookup-types/lookup/:lookupKey', component: LookupComponent },
      { path: 'contactstore/:campaignId/campaign',component: ContactstoreComponent },
      { path: 'contact', component: ContactLandingComponent,
        data: { breadcrumb: 'Contact' },
        children: [
          { path: '', component: ContactComponent},
          { path: 'upload', component: UploadContactsComponent, data: { breadcrumb: 'File' }},
          { path: 'details/:longContactId', 
            component: ContactDetailsLandingComponent, 
            data: { breadcrumb: 'Detail' },
            children: [
              { path: '', component: ContactDetailsComponent},
              { path: 'trace', component: TraceComponent },
              { path: 'personal-details', component: PersonalDetailsComponent},
              { path: 'notes', component: NotesComponent},
            ]
          }
        ]
      },
      { path: 'contactstore-edit/:contactStoreId', component: EditContactStoreComponent,
        children: [
          { path: '', component: UpdateContactStoreComponent},
          { path: 'dedupe-settings', component: DedupeSettingsComponent },
          { path: 'vdn-settings', component: VdnComponent },
          { path: 'sms-settings', component: SmsSettingsComponent }
        ]
      },
      { path: 'contact-store/sms-settings/:contactStoreId/add', component: AddSmsSettingsComponent },
    ]
  }
];
