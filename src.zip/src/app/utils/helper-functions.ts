export class HelperFunctions {
  static toQueryParameters<T>(queryFilter: T): string{
    var object = {...queryFilter};
    return new URLSearchParams(object as any).toString();
  }

  static generateQueryRequest(queryObject: any): string {
    const queryParams: string[] = [];

    for (const [key, value] of Object.entries(queryObject)) {
      if (value === null || value === undefined) continue;

      if (Array.isArray(value)) {
        value.forEach(item => {
          queryParams.push(`${encodeURIComponent(key)}=${encodeURIComponent(item.toString())}`);
        });
      } else {
        queryParams.push(`${encodeURIComponent(key)}=${encodeURIComponent(value.toString())}`);
      }
    }
    return queryParams.join('&');
  }

}
