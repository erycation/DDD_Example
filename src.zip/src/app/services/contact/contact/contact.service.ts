import { inject, Injectable } from "@angular/core";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { Observable } from "rxjs";
import { HelperFunctions } from "../../../utils/helper-functions";
import { ContactDto } from "../../../models/contact-crud/contact/contact-dto";
import { ContactQueryFilterLimitDto } from "../../../models/contact-crud/contact/contact-query-limit-dto";
import { ContactQueryFilterDto } from "../../../models/contact-crud/contact/contact-query-dto";
import { ResponseApi } from "../../../models/cdm-portal/response-api.model";
import { UpdateContactDto } from "../../../models/contact-crud/contact/update-contact-dto";
import { UpdateContactRequestDto } from "../../../models/contact-crud/contact/update-contact-request-dto";

@Injectable({
  providedIn: 'root'
})
export class ContactService{
  private client = inject(ContactApiClient);

  getContactByQueryLimit(contactQueryData: ContactQueryFilterLimitDto): Observable<ContactDto[]> {
      var queryParams = HelperFunctions.generateQueryRequest(contactQueryData);
      return this.client.get<ContactDto[]>(`/contact/query-limit?${queryParams}`);
    }

  getContactByQuery(contactQueryData: ContactQueryFilterDto): Observable<ContactDto[]> {
      var queryParams = HelperFunctions.generateQueryRequest(contactQueryData);
      return this.client.get<ContactDto[]>(`/contact/query?${queryParams}`);
    }

  updateContact(contactUpdateDto: UpdateContactDto, contactUpdateRequestDto: UpdateContactRequestDto ): Observable<ResponseApi<ContactDto>> {
    var requestParams = HelperFunctions.generateQueryRequest(contactUpdateRequestDto);
    return this.client.put<ResponseApi<ContactDto>>(`/Contact?${requestParams}`, contactUpdateDto);
  }
}