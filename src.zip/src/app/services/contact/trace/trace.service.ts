import { inject, Injectable } from "@angular/core";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { Observable } from "rxjs";
import { HelperFunctions } from "../../../utils/helper-functions";
import { TraceDto } from "../../../models/contact-crud/trace/trace-dto";
import { TraceQueryFilterDto } from "../../../models/contact-crud/trace/trace-query-dto";

@Injectable({
  providedIn: 'root'
})
export class TraceService{
  private client = inject(ContactApiClient);

  getTraceByQuery(traceQueryData: TraceQueryFilterDto): Observable<TraceDto[]> {
      var queryParams = HelperFunctions.generateQueryRequest(traceQueryData);
      return this.client.get<TraceDto[]>(`/Trace/Query?${queryParams}`);
    }
    
}