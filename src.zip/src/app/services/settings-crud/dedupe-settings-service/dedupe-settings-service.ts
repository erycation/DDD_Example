import { inject, Injectable } from "@angular/core";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { DedupeSettingUpdateDto } from "../../../models/settings-crud/dedupe-settings/dedupe-setting-update-dto";
import { Observable } from "rxjs";
import { DedupeSettingDto } from "../../../models/settings-crud/dedupe-settings/dedupe-setting-dto";
import { DedupeSettingAddDto } from "../../../models/settings-crud/dedupe-settings/dedupe-setting-add-dto";
import { ResponseApi } from "../../../models/cdm-portal/response-api.model";

@Injectable({
  providedIn: 'root'
})
export class DedupeSettingsService {
  private client = inject(ContactApiClient);

  public addDedupeSettings(dedupeSettingsAddDto: DedupeSettingAddDto): Observable<ResponseApi<DedupeSettingDto>> {
    return this.client.post(`/dedupe-settings`, dedupeSettingsAddDto);
  }

  public getDedupeSettingsByContactStoreId(contactStoreId: number): Observable<DedupeSettingDto[]> {
    return this.client.get(`/dedupe-settings/by-contact-store/${contactStoreId}`);
  }

  public updateDedupeSettings(
    dedupeSettingsId: number, dedupeSettingsUpdateDto: DedupeSettingUpdateDto
  ): Observable<ResponseApi<DedupeSettingDto>> {
    return this.client.put(`/dedupe-settings/${dedupeSettingsId}`, dedupeSettingsUpdateDto);
  }
}