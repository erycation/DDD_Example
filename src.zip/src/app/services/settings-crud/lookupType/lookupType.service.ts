import { inject, Injectable } from '@angular/core';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { Observable, Subject } from 'rxjs';
import { LookupTypeDto } from '../../../models/settings-crud/lookup-types/lookup-type-dto';
import { LookupTypeAddDto } from '../../../models/settings-crud/lookup-types/lookup-type-add-dto';
import { LookupTypeUpdateDto } from '../../../models/settings-crud/lookup-types/lookup-type-update-dto';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';

@Injectable({
  providedIn: 'root'
})
export class LookupTypeService {

  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addLookupType(dto: LookupTypeAddDto): Observable<ResponseApi<LookupTypeDto>> {
    return this.client.post<ResponseApi<LookupTypeDto>>(`/LookupType`, dto);
  }

  updateLookupType(key: string, dto: LookupTypeUpdateDto): Observable<ResponseApi<LookupTypeDto>> {
    return this.client.put<ResponseApi<LookupTypeDto>>(`/LookupType/${key}`, dto);
  }

  getLookupTypeByKey(key: string): Observable<LookupTypeDto> {
    return this.client.get<LookupTypeDto>(`/LookupType/Key/${key}`);
  }

  getLookupTypes(): Observable<LookupTypeDto[]> {
    return this.client.get<LookupTypeDto[]>(`/LookupType/All`);
  }

  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}
