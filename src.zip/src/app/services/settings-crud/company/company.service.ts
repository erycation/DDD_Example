import { inject, Injectable } from '@angular/core';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { Observable, Subject } from 'rxjs';
import { CompanyDto } from '../../../models/settings-crud/companies/company-dto';
import { CompanyAddDto } from '../../../models/settings-crud/companies/company-add-dto';
import { CompanyUpdateDto } from '../../../models/settings-crud/companies/company-update-dto';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addCompany(companyAddDto: CompanyAddDto): Observable<ResponseApi<CompanyDto>> {
    return this.client.post<ResponseApi<CompanyDto>>(`/Company`, companyAddDto);
  }

  updateCompany(companyId : number, companyUpdateDto: CompanyUpdateDto): Observable<ResponseApi<CompanyDto>> {
    return this.client.put<ResponseApi<CompanyDto>>(`/Company/${companyId}`, companyUpdateDto);
  }
  
  getCompanyById(companyId: number): Observable<CompanyDto> {
    return this.client.get<CompanyDto>(`/Company/${companyId}`);
  }

  getCompanies(): Observable<CompanyDto[]> {
    return this.client.get<CompanyDto[]>(`/Company/All`);
  }

  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}