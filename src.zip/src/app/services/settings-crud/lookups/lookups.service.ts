import { inject, Injectable } from "@angular/core";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { Observable } from "rxjs";
import { LookupDto } from "../../../models/settings-crud/lookups/lookup-dto";
import { LookupQueryFilterDto } from "../../../models/settings-crud/lookups/lookup-query-filter-dto";
import { ResponseApi } from "../../../models/cdm-portal/response-api.model";
import { LookupUpdateDto } from "../../../models/settings-crud/lookups/lookup-update-dto";
import { HelperFunctions } from "../../../utils/helper-functions";
import { LookupAddDto } from "../../../models/settings-crud/lookups/lookup-add-dto";

@Injectable({
  providedIn: 'root'
})
export class LookupService{
  private client = inject(ContactApiClient);

  getLookupsBySystemName(systemName: string): Observable<Record<string, Array<LookupDto>>> {
    return this.client.get(`/Lookup/LookupsBySystem?systemName=${systemName}`);
  }

  updateLookup(lookupId : number, lookupUpdateDto: LookupUpdateDto): Observable<ResponseApi<LookupDto>> {
    return this.client.put<ResponseApi<LookupDto>>(`/Lookup/${lookupId}`, lookupUpdateDto);
  }

  addLookup(lookupAddDto: LookupAddDto): Observable<ResponseApi<LookupDto>> {
    return this.client.post<ResponseApi<LookupDto>>(`/Lookup`, lookupAddDto);
  }

  getLookupsByQuery(LookupQuery: LookupQueryFilterDto): Observable<LookupDto[]> {
      var queryParams = HelperFunctions.generateQueryRequest(LookupQuery);
      return this.client.get(`/Lookup/Query?${queryParams}`);
    }
    
  getLookups(): Observable<LookupDto[]> {
      return this.client.get(`/Lookup/All`);
    }

  getLookupById(lookupId: number): Observable<LookupDto> {
      return this.client.get(`/Lookup/${lookupId}`);
    }
}