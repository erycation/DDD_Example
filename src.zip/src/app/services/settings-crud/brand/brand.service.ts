import { inject, Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
import { BrandAddDto } from '../../../models/settings-crud/brands/brand-add-dto';
import { BrandUpdateDto } from '../../../models/settings-crud/brands/brand-update-dto';
import { BrandDto } from '../../../models/settings-crud/brands/brand-dto';
import { BrandQueryFilterDto } from '../../../models/settings-crud/brands/brand-query-filter-dto';
import { HelperFunctions } from '../../../utils/helper-functions';

@Injectable({
  providedIn: 'root'
})
export class BrandService {
  
  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addBrand(brandAddDto: BrandAddDto): Observable<ResponseApi<BrandDto>> {
    return this.client.post<ResponseApi<BrandDto>>(`/brand`, brandAddDto);
  }

  updateBrand(brandId : number, brandUpdateDto: BrandUpdateDto): Observable<ResponseApi<BrandDto>> {
    return this.client.put<ResponseApi<BrandDto>>(`/brand/${brandId}`, brandUpdateDto);
  }
  
  getBrandsByQuery(brandQuery: BrandQueryFilterDto): Observable<BrandDto[]> {
    var queryParams = HelperFunctions.generateQueryRequest(brandQuery);
    return this.client.get(`/brand/query?${queryParams}`);
  }

  getBrands(): Observable<BrandDto[]> {
     return this.client.get<BrandDto[]>(`/brand/all`);
   }
   
  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}