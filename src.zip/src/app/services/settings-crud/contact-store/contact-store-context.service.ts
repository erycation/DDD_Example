import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { ContactStoreDto } from "../../../models/settings-crud/contact-stores/contact-store-dto";
import { LookupDto } from "../../../models/settings-crud/lookups/lookup-dto";

@Injectable({
  providedIn: 'root'
})
export class ContactStoreContextService {
  private contactStoreId = new BehaviorSubject<number>(0);
  public contactStoreId$ = this.contactStoreId.asObservable();

  private contactStores = new BehaviorSubject<ContactStoreDto[]>([]);
  public contactStores$ = this.contactStores.asObservable();

  private contactStoreLookups = new BehaviorSubject<Record<string, Array<any>>>({});
  public contactStoreLookups$ = this.contactStoreLookups.asObservable();

  addContactStores(contactStore: ContactStoreDto) {
    const currentStores = this.contactStores.getValue();
    const index = currentStores.findIndex(store => store.id === contactStore.id);
    if (index !== -1) {
      currentStores.splice(index, 1); // Remove existing store if it exists
    }
    this.contactStores.next([...currentStores, contactStore]);
  }

  getContactStore(contactStoreId: number): ContactStoreDto | undefined {
    const currentStores = this.contactStores.getValue();
    return currentStores.find(store => store.id === contactStoreId);
  }

  addContactStoreLookups(lookups: Record<string, Array<LookupDto>>) {
    const currentLookups = this.contactStoreLookups.getValue();
    const updatedLookups = { ...currentLookups, ...lookups };
    this.contactStoreLookups.next(updatedLookups);
  }

  getContactStoreLookups(): Record<string, Array<LookupDto>> {
    return this.contactStoreLookups.getValue();
  }

  addContactStoreId(contactStoreId: number) {
    this.contactStoreId.next(contactStoreId);
  }

  getContactStoreId(): number {
    return this.contactStoreId.getValue();
  }
}