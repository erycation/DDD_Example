import { ContactStoreDto } from '../../../models/settings-crud/contact-stores/contact-store-dto';
import { inject, Injectable } from "@angular/core";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { Observable } from "rxjs";
import { ContactStoreQueryFilterDto } from '../../../models/settings-crud/contact-stores/contact-store-query-filter.dto';
import { HelperFunctions } from '../../../utils/helper-functions';
import { ContactStoreUpdateDto } from '../../../models/settings-crud/contact-stores/contact-store-update-dto';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';

@Injectable({
  providedIn: 'root'
})
export class ContactStoreService {
  private client = inject(ContactApiClient);

  getContactStoresByQuery(contactStoreQuery: ContactStoreQueryFilterDto): Observable<ContactStoreDto[]> {
    var queryParams = HelperFunctions.toQueryParameters(contactStoreQuery);
    return this.client.get(`/ContactStore/Query?${queryParams}`);
  }

  updateContactStore(contactStoreId: number, updateContactStoreDto: ContactStoreUpdateDto): Observable<ResponseApi<ContactStoreDto>> {
    return this.client.put<ResponseApi<ContactStoreDto>>(`/ContactStore/${contactStoreId}`, updateContactStoreDto);
  }
  
  getContactStore(contactStoreId: number): Observable<ContactStoreDto> {
    return this.client.get<ContactStoreDto>(`/ContactStore/${contactStoreId}`);
  }
}
