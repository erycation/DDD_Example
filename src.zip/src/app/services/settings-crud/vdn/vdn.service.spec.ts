import { TestBed } from '@angular/core/testing';
import { VdnService } from './vdn.service';


describe('VdnService', () => {
  let service: VdnService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VdnService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
