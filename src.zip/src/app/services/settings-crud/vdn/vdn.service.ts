import { inject, Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
import { VdnAddDto } from '../../../models/settings-crud/vdns/vdn-add-dto';
import { VdnDto } from '../../../models/settings-crud/vdns/vdn-dto';
import { VdnUpdateDto } from '../../../models/settings-crud/vdns/vdn-update-dto';
import { VdnQueryFilter } from '../../../models/settings-crud/vdns/vdn-query-filter';
import { HelperFunctions } from '../../../utils/helper-functions';

@Injectable({
  providedIn: 'root'
})
export class VdnService {
  
  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addVdn(vdnAddDto: VdnAddDto): Observable<ResponseApi<VdnDto>> {
    return this.client.post<ResponseApi<VdnDto>>(`/Vdn`, vdnAddDto);
  }

  updateVdn(vdnId : number, vdnUpdateDto: VdnUpdateDto): Observable<ResponseApi<VdnDto>> {
    return this.client.put<ResponseApi<VdnDto>>(`/Vdn/${vdnId}`, vdnUpdateDto);
  }
  
  getVdnById(vdnId: number): Observable<VdnDto> {
    return this.client.get<VdnDto>(`/Vdn/${vdnId}`);
  }

  getVdns(): Observable<VdnDto[]> {
    return this.client.get<VdnDto[]>(`/Vdn/All`);
  }

  getWapDestinationVdns(contactStoreId: number): Observable<VdnDto[]> {
    return this.client.get<VdnDto[]>(`/Vdn/wap-destination-vdns/${contactStoreId}`);
  }

  getVdnsByQuery(query: VdnQueryFilter): Observable<VdnDto[]> {
    return this.client.get<VdnDto[]>(`/vdn/query?${HelperFunctions.toQueryParameters(query)}`);
  }

  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}
