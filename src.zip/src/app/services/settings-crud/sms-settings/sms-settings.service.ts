import { inject, Injectable } from "@angular/core";
import { SmsDto } from "../../../models/settings-crud/smses/sms-dto";
import { ContactApiClient } from "../../../api-clients/contact-api";
import { SmsQueryFilterDto } from "../../../models/settings-crud/smses/sms-query-filter-dto";
import { HelperFunctions } from "../../../utils/helper-functions";
import { Observable } from "rxjs";
import { SmsUpdateDto } from "../../../models/settings-crud/smses/sms-update-dto";
import { ResponseApi } from "../../../models/cdm-portal/response-api.model";
import { SmsAddDto } from "../../../models/settings-crud/smses/sms-add-dto";

@Injectable({
  providedIn: 'root'
})
export class SmsSettingsService {
  private client = inject(ContactApiClient);
  
  getSmsSettings(smsQueryFilter: SmsQueryFilterDto): Observable<SmsDto[]> {
    var queryParams = HelperFunctions.toQueryParameters(smsQueryFilter);
    return this.client.get(`/sms/query?${queryParams}`);
  }

  updateSmsSettings(smsSettingsId: number, smsSettingsUpdateDto: SmsUpdateDto): Observable<ResponseApi<SmsDto>> {
    return this.client.put(`/sms/${smsSettingsId}`, smsSettingsUpdateDto);
  }

  addBulkSmsSettings(smsSettings: SmsAddDto[]): Observable<ResponseApi<boolean>> {
    return this.client.post(`/sms/bulk`, smsSettings);
  }
}