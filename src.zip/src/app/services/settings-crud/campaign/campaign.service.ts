import { inject, Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
import { CampaignAddDto } from '../../../models/settings-crud/campaigns/campaign-add-dto';
import { CampaignUpdateDto } from '../../../models/settings-crud/campaigns/campaign-update-dto';
import { CampaignDto } from '../../../models/settings-crud/campaigns/campaign-dto';
import { CampaignDetailDto } from '../../../models/settings-crud/campaigns/campaign-detail-dto';

@Injectable({
  providedIn: 'root'
})
export class CampaignService {
  
  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addCampaign(campaignAddDto: CampaignAddDto): Observable<ResponseApi<CampaignDto>> {
    return this.client.post<ResponseApi<CampaignDto>>(`/Campaign`, campaignAddDto);
  }

  updateCampaign(campaignId : number, campaignUpdateDto: CampaignUpdateDto): Observable<ResponseApi<CampaignDto>> {
    return this.client.put<ResponseApi<CampaignDto>>(`/Campaign/${campaignId}`, campaignUpdateDto);
  }
  
  getCampaignById(campaignId: number): Observable<CampaignDto> {
    return this.client.get<CampaignDto>(`/Campaign/${campaignId}`);
  }

  getCampaigns(): Observable<CampaignDto[]> {
    return this.client.get<CampaignDto[]>(`/Campaign/All`);
  }

  getCampaignByVdn(vdnNumber: string): Observable<CampaignDetailDto> {
    return this.client.get<CampaignDto>(`/Campaign/Detail/${vdnNumber}`);
  }

  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}
