import { TestBed } from '@angular/core/testing';
import { SmsLookupService } from './sms-lookup.service';

describe('SmsLookupService', () => {
  let service: SmsLookupService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SmsLookupService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});