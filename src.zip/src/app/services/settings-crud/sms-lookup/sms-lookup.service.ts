import { inject, Injectable } from '@angular/core';
import { ContactApiClient } from '../../../api-clients/contact-api';
import { Observable, Subject } from 'rxjs';
import { SmsLookupDto } from '../../../models/settings-crud/sms-lookups/sms-lookup-dto';
import { SmsLookupAddDto } from '../../../models/settings-crud/sms-lookups/sms-lookup-add-dto';
import { SmsLookupUpdateDto } from '../../../models/settings-crud/sms-lookups/sms-lookup-update-dto';
import { ResponseApi } from '../../../models/cdm-portal/response-api.model';
import { SmsLookupQueryFilter } from '../../../models/settings-crud/sms-lookups/sms-lookup-query-filter';
import { HelperFunctions } from '../../../utils/helper-functions';

@Injectable({
  providedIn: 'root'
})
export class SmsLookupService {
  client = inject(ContactApiClient);
  private actioned = new Subject<boolean>();
  actioned$ = this.actioned.asObservable();

  addSmsLookup(smsLookupAddDto: SmsLookupAddDto): Observable<ResponseApi<SmsLookupDto>> {
    return this.client.post<ResponseApi<SmsLookupDto>>(`/sms-lookup`, smsLookupAddDto);
  }

  updateSmsLookup(smsLookupId: number, smsLookupUpdateDto: SmsLookupUpdateDto): Observable<ResponseApi<SmsLookupDto>> {
    return this.client.put<ResponseApi<SmsLookupDto>>(`/sms-lookup/${smsLookupId}`, smsLookupUpdateDto);
  }

  getSmsLookupById(smsLookupId: number): Observable<SmsLookupDto> {
    return this.client.get<SmsLookupDto>(`/sms-lookup/${smsLookupId}`);
  }

  getSmsLookups(): Observable<SmsLookupDto[]> {
    return this.client.get<SmsLookupDto[]>(`/sms-lookup/all`);
  }

  getSmsLookupsByQuery(queryFilter: SmsLookupQueryFilter): Observable<SmsLookupDto[]> {
    var queryParams = HelperFunctions.toQueryParameters(queryFilter);
    return this.client.get<SmsLookupDto[]>(`/sms-lookup/query?${queryParams}`);
  }

  emitValue(value: boolean) {
    this.actioned.next(value);
  }
}