import { inject, Injectable } from '@angular/core';
import {
  MatSnackBar
} from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class ToastService {

  toast = inject(MatSnackBar);

  success(message: string, actionButton: string = 'Close', duration: number = 3000) {
    this.openToast(message, actionButton, duration, 'snackbar-success');
  }

  error(message: string, actionButton: string = 'Close', duration: number = 3000) {
    this.openToast(message, actionButton, duration, 'snackbar-error');
  }

  info(message: string, actionButton: string = 'Close', duration: number = 3000) {
    this.openToast(message, actionButton, duration, 'snackbar-info');
  }

  warning(message: string, actionButton: string = 'Close', duration: number = 3000) {
    this.openToast(message, actionButton, duration, 'snackbar-warning');
  }

  private openToast(
    message: string,
    actionButton: string,
    duration: number,
    panelClass: string
  ) {
    this.toast.open(message, actionButton, {
      duration: duration,
      horizontalPosition: 'right',
      verticalPosition: 'bottom',
      panelClass: [panelClass],
    });
  }
}