import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoadingSpinnerService {

  loading = new BehaviorSubject<boolean>(false);

  setLoading(loading: boolean) {
    this.loading.next(loading);
  }
}