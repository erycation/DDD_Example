export interface ContactQueryFilterDto {
  longContactId?: string;
  contactId?: string;
  cellNumber?: string;
  idNumber?: string;
  email?: string;
}