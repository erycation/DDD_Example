export interface ContactQueryFilterLimitDto {
    contactSource?: string | undefined;
    contactStatus?: string | undefined;
    dedupeStatus?: string | undefined;
    limit?: number | undefined;
    startDate?: string;
    endDate?: string;
}