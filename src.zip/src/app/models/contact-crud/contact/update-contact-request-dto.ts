export interface UpdateContactRequestDto {
  contactId?: string;
  longContactId?: string;
}
