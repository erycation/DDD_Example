export interface TraceDto {
    changedBy?: string | undefined;
    longContactId?: string | undefined;
    comments?: string | undefined;
    info?: string | undefined;
    dateCreated?: Date;
}