export interface TraceQueryFilterDto {
    longContactId?: string | undefined;
}