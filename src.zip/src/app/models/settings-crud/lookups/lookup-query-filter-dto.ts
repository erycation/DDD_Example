export interface LookupQueryFilterDto{
  name?: string;
  code?: number;
  key?: string;
}