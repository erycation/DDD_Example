export interface BaseLookupDto {
    key?: string | undefined;
    code?: number | undefined;
    name?: string | undefined;
}