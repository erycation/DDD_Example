import { BaseLookupDto } from "./base-lookup-dto";

export interface LookupAddDto extends BaseLookupDto {
    addedById?: number;
}