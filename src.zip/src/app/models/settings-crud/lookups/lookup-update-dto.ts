import { BaseLookupDto } from "./base-lookup-dto";

export interface LookupUpdateDto extends BaseLookupDto {
    updatedById?: number | undefined;
    isActive?: boolean | undefined;
}