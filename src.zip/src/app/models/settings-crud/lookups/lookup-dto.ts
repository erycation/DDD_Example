import { BaseLookupDto } from "./base-lookup-dto";

export interface LookupDto extends BaseLookupDto {
    id?: number;
    addedById?: number;
    addedDateTime?: Date;
    updatedById?: number | undefined;
    isActive?: boolean | undefined;
    updatedDateTime?: Date | undefined;
}