import { BaseConnextListStoreDto } from "./base-connex-list-store-dto";

export interface ConnextListStoreAddDto extends BaseConnextListStoreDto {

}