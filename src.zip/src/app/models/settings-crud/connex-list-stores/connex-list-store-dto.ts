import { BaseConnextListStoreDto } from "./base-connex-list-store-dto";

export interface ConnexListStoreDto extends BaseConnextListStoreDto {
    id?: number;
    isActive?: boolean | undefined;
    contactStoreName?: string | undefined;
    connexCamaignId?: string | undefined;
    campaignId?: number | undefined;
}