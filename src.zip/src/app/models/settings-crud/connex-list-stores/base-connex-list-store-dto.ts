export interface BaseConnextListStoreDto {
    connexListId?: string;
    contactStoreId?: number;
}