import { LookupDto } from "../lookups/lookup-dto";
import { BaseLookupTypeDto } from "./base-lookup-type-dto";

export interface LookupTypeAddDto extends BaseLookupTypeDto {
    key: string;
    addedById?: number;
    lookups?: LookupDto[];
}