import { BaseLookupTypeDto } from "./base-lookup-type-dto";

export interface LookupTypeDto extends BaseLookupTypeDto {
    key: string;    
    addedById?: number;
    addedDateTime?: Date;
    updatedById?: number;
    updatedDateTime?: Date;
    isActive?: boolean;
}