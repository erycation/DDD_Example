import { BaseLookupTypeDto } from "./base-lookup-type-dto";

export interface LookupTypeUpdateDto extends BaseLookupTypeDto {
    updatedById?: number;
    isActive?: boolean;
}