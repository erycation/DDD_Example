export interface BaseLookupTypeDto {
    isStatic?: boolean;
    description?: string;
}