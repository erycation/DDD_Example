import { WarmUpBrandTypeDto } from "../warm-up-brand-types/warm-up-brand-type-dto";
import { BaseOnePlanBrandDto } from "./base-one-plan-brand-dto";

export interface OnePlanBrandDto extends BaseOnePlanBrandDto {
    warmUpBrandTypeDto?: WarmUpBrandTypeDto;
}