export interface BaseOnePlanBrandDto {
    brandTypeId?: number | undefined;
    externalUrl?: string | undefined;
}