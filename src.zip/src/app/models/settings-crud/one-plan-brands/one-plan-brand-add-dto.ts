import { BaseOnePlanBrandDto } from "./base-one-plan-brand-dto";

export interface OnePlanBrandAddDto extends BaseOnePlanBrandDto {
   
}