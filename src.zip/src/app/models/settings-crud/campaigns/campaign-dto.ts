import { LookupDto } from "../lookups/lookup-dto";
import { BaseCampaignDto } from "./base-campaign-dto";

export interface CampaignDto extends BaseCampaignDto {
    id?: number;
    isActive?: boolean;
    sourceCount: number;
    addedDateTime?: Date;
    updatedDateTime?: Date;
    businessUnitDto?: LookupDto;
    businessFunctionDto?: LookupDto;
    campaignModeDto?: LookupDto;
}