export interface CampaignDetailDto {
    pomCampaignId?: number;
    campaignId?: number;
    isOutboundCampaign?: boolean;
    businessUnitId?: number;
    businessFunctionId?: number;
    businessUnitName?: string | undefined;
    pomCampaignName?: string | undefined;
    contactSourceId?: number;
    contactSourceName?: string | undefined;
    businessFunctionName?: string | undefined;
    companyName?: string | undefined;
    vdnNo?: string | undefined;
    brokerCode?: string | undefined;
    dialerLookupId?: number;
}