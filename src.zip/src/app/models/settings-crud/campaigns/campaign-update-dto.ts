import { BaseCampaignDto } from "./base-campaign-dto";

export interface CampaignUpdateDto extends BaseCampaignDto {
    updatedById?: number | undefined;
    isActive?: boolean | undefined;
    id?: number;
}