import { BaseCampaignDto } from "./base-campaign-dto";

export interface CampaignAddDto extends BaseCampaignDto {
    addedById?: number | undefined;
}