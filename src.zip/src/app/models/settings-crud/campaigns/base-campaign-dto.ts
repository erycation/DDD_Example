export interface BaseCampaignDto {
    pomCampaignId?: number | undefined;
    businessUnitId?: number | undefined;
    businessFunctionId?: number | undefined;
    campaignModeId?: number | undefined;
    campaignName?: string | undefined;
    vdn?: string | undefined;
    source?: string | undefined;
}