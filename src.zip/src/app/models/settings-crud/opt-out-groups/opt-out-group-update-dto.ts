import { BaseOptOutGroupDto } from "./base-opt-out-group-dto";

export interface OptOutGroupUpdateDto extends BaseOptOutGroupDto {
    isActive?: boolean | undefined;
    updatedById?: number | undefined;
}