import { BaseOptOutGroupDto } from "./base-opt-out-group-dto";

export interface OptOutGroupDto extends BaseOptOutGroupDto {
    isActive?: boolean | undefined;
    id?: number;
    dateCreated?: Date;
    addedById?: number;
    addedDateTime?: Date;
    updatedById?: number;
    updatedDateTime?: Date;
}