export interface BaseOptOutGroupDto {
    name?: string | undefined;
}