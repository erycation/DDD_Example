import { BaseOptOutGroupDto } from "./base-opt-out-group-dto";

export interface OptOutGroupAddDto extends BaseOptOutGroupDto {
    addedById?: number;
}