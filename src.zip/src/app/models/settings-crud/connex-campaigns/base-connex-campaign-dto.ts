export interface BaseConnexCampaignDto {
    connexCampaignId?: string;
    campaignId?: number;
    campaignName?: string | undefined;
}