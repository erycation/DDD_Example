import { BaseConnexCampaignDto } from "./base-connex-campaign-dto";

export interface ConnexCampaignDto extends BaseConnexCampaignDto {
    isActive?: boolean;
}