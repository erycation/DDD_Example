import { BaseConnexCampaignDto } from "./base-connex-campaign-dto";

export interface ConnexCampaignAddDto extends BaseConnexCampaignDto {

}