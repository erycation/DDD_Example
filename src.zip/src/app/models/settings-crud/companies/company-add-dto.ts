import { BaseCompanyDto } from "./base-company-dto";

export interface CompanyAddDto extends BaseCompanyDto {

}