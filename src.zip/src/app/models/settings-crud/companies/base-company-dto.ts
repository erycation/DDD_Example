export interface BaseCompanyDto {
    name?: string | undefined;
    companyCode?: string | undefined;
    policyCompany?: string | undefined;
    underwritingCompany?: string | undefined;
    fspDetails?: string | undefined;
    contactNumber?: string | undefined;
    brokerCode?: string | undefined;
}