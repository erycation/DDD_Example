import { BaseCompanyDto } from "./base-company-dto";

export interface CompanyDto extends BaseCompanyDto {
    id?: number;
    dateCreated?: Date | undefined;
    addedDateTime?: Date;
    updatedDateTime?: Date | undefined;
    updatedById?: number | undefined;
    isActive?: boolean;
}