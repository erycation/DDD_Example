import { BaseCompanyDto } from "./base-company-dto";

export interface CompanyUpdateDto extends BaseCompanyDto {
    updatedById?: number | undefined;
    isActive?: boolean;
}