export interface BaseVdnSettingDto {
    vdnSettingId?: number;
    vdnNumber?: string | undefined;
    vdnDescription?: string | undefined;
    vdnStatus?: string | undefined;
    lastChangeOperator?: string | undefined;
    actionUser?: string | undefined;
    changeDate?: Date | undefined;
    amendmentDate?: Date | undefined;
    channel?: string | undefined;
    mediaDescription?: string | undefined;
    mediaType?: string | undefined;
}