import { BaseVdnSettingDto } from "./base-vdn-setting-dto";

export interface VdnSettingDto extends BaseVdnSettingDto {

}