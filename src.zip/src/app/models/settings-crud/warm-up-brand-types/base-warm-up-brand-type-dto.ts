export interface BaseWarmUpBrandTypeDto {
    brandTypeId?: number;
    brandCode?: string | undefined;
    brandDescription?: string | undefined;
}