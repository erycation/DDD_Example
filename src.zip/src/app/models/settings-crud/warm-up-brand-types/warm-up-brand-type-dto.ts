import { BaseWarmUpBrandTypeDto } from "./base-warm-up-brand-type-dto";

export interface WarmUpBrandTypeDto extends BaseWarmUpBrandTypeDto {

}