import { BaseSmsDto } from "./base-sms-dto";

export interface SmsUpdateDto extends BaseSmsDto{
    isActive?: boolean | undefined;
    updatedById?: number | undefined;
}