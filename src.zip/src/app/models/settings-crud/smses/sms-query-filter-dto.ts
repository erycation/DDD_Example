export interface SmsQueryFilterDto {
  contactStoreId?: number;
  isActive?: boolean;
}