export interface BaseSmsDto {
    contactStoreId?: number | undefined;
    attempt?: number | undefined;
    smsLookupId?: number | undefined;    
}