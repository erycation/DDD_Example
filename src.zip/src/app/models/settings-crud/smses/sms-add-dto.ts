import { BaseSmsDto } from "./base-sms-dto";

export interface SmsAddDto extends BaseSmsDto {
    addedById?: number;
}