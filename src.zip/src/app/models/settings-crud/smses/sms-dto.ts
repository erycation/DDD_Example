import { SmsLookupDto } from "../sms-lookups/sms-lookup-dto";
import { BaseSmsDto } from "./base-sms-dto";

export interface SmsDto extends BaseSmsDto {
    id?: number;
    dateCreated?: Date | undefined;
    addedById?: number;
    addedDateTime?: Date;
    updatedById?: number | undefined;
    updatedDateTime?: Date | undefined;
    isActive?: boolean | undefined;
    smsLookup: SmsLookupDto;
}