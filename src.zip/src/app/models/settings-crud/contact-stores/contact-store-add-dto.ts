import { BaseContactStoreDto } from "./base-contact-store-dto";

export interface ContactStoreAddDto extends BaseContactStoreDto {

}