export interface ContactStoreQueryFilterDto{
  campaignId: string;
}