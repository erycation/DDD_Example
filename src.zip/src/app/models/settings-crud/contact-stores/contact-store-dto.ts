import { CampaignDto } from "../campaigns/campaign-dto";
import { ConnexContactPriorityDto } from "../connex-priorities/connex-contact-priority-dto";
import { LookupDto } from "../lookups/lookup-dto";
import { BaseContactStoreDto } from "./base-contact-store-dto";

export interface ContactStoreDto extends BaseContactStoreDto {
  id?: number;
  isActive?: boolean | undefined;
  dateCreated?: Date | undefined;
  campaign?: CampaignDto;
  contactStoreMode?: LookupDto;
  transferDestination?: LookupDto;
  shortCode?: LookupDto;
  contactOrigin?: LookupDto;
  campaignType?: LookupDto;
  connexContactPriorities?: ConnexContactPriorityDto;
}