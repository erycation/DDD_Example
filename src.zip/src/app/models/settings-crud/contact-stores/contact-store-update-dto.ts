import { ConnexContactPriorityUpdateDto } from "../connex-priorities/connex-contact-priority-update-dto";
import { BaseContactStoreDto } from "./base-contact-store-dto";

export interface ContactStoreUpdateDto extends BaseContactStoreDto {
  isActive?: boolean | null;
  connexContactPriorities?: ConnexContactPriorityUpdateDto;
}