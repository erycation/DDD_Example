import { BaseBrandDto } from "./base-brand-dto";

export interface BrandUpdateDto extends BaseBrandDto {
    isActive?: boolean | undefined;
}