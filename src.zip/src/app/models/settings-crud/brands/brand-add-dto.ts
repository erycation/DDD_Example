import { BaseBrandDto } from "./base-brand-dto";

export interface BrandAddDto extends BaseBrandDto {
    
}