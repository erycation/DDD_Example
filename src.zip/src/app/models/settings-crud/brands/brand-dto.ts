import { BaseBrandDto } from "./base-brand-dto";

export interface BrandDto extends BaseBrandDto {
    id?: number | undefined;
    isActive?: boolean | undefined;
}