 
export interface BaseBrandDto{
    brandName?: string | undefined;
    saleType?: string | undefined;
    businessIdentifier?: string | undefined;
    companyCode?: string | undefined;
    underwritingCompany?: string | undefined;
    brandCode?: string | undefined;
}