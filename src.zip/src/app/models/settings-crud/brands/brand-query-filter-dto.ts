export interface BrandQueryFilterDto{
  brandName?:string
  businessIdentifier?:string
  companyCode?:string
  underwritingCompany?:string
  brandCode?:string
}