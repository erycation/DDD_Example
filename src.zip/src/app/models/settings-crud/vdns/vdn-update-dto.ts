import { BaseVdnDto } from "./base-vdn-dto";

export interface VdnUpdateDto extends BaseVdnDto {
    updatedById?: number | undefined;
}