export interface BaseVdnDto {
    vdnNo?: string | undefined;
    contactStoreId?: number | undefined;
    smsCampaignId?: boolean | undefined;
    isActive?: boolean | undefined;
    campaignStory?: string | undefined;
    agentScript?: string | undefined;
    companyId?: number | undefined;
    usePodSystem?: boolean | undefined;
    useEpodSystem?: boolean | undefined;
    isAllWomen?: boolean | undefined;
    isFuneral?: boolean | undefined;
    isOnePlan?: boolean | undefined;
    brokerCode?: string | undefined;
}