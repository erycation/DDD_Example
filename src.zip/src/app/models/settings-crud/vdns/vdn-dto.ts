import { CompanyDto } from "../companies/company-dto";
import { BaseVdnDto } from "./base-vdn-dto";

export interface VdnDto extends BaseVdnDto {
    id?: number;
    addedDateTime?: Date;
    updatedDateTime?: Date;
    addedById?: number | undefined;
    updatedById?: number | undefined;
    companyDto?: CompanyDto;
}