import { BaseVdnDto } from "./base-vdn-dto";

export interface VdnAddDto extends BaseVdnDto {
    addedById?: number | undefined;
}