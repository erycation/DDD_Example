export interface VdnQueryFilter {
  isActive?: boolean;
  contactStoreId?: number;
  brokerCode?: string;
  vdnNo?: string;
}
