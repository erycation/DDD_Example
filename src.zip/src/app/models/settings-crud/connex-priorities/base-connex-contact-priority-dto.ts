export interface BaseConnexContactPriorityDto {
  priorityBulk: number;
  prioritySingle: number;
}