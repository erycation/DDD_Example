import { BaseConnexContactPriorityDto } from "./base-connex-contact-priority-dto";

export interface ConnexContactPriorityUpdateDto extends BaseConnexContactPriorityDto {}