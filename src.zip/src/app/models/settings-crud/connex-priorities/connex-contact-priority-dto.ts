import { BaseConnexContactPriorityDto } from "./base-connex-contact-priority-dto";

export interface ConnexContactPriorityDto extends BaseConnexContactPriorityDto {
  contactStoresId: number;
}