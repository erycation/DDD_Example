export interface BaseSmsLookupDto {
    typeId?: number;
    englishMessage?: string | undefined;
    afrikaansMessage?: string | undefined;
    isActive?: boolean | undefined;
    typeKey?: string | undefined;
    companyId?: number | undefined;
    title?: string | undefined;  
    companyName?: string;  
    typeName?: string;
}