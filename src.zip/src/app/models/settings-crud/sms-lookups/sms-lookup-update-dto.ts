import { BaseSmsLookupDto } from "./base-sms-lookup-dto";

export interface SmsLookupUpdateDto extends BaseSmsLookupDto {
    updatedById?: number | undefined;
}