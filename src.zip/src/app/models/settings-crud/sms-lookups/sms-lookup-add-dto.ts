import { BaseSmsLookupDto } from "./base-sms-lookup-dto";

export interface SmsLookupAddDto extends BaseSmsLookupDto {
    addedById?: number;
}