import { LookupDto } from "../lookups/lookup-dto";
import { BaseSmsLookupDto } from "./base-sms-lookup-dto";

export interface SmsLookupDto extends BaseSmsLookupDto {    
    id?: number;
    dateCreated?: Date | undefined;
    addedById?: number | undefined;
    addedDateTime?: Date;
    updatedById?: number | undefined;
    updatedDateTime?: Date | undefined;
    smsType: LookupDto;
}