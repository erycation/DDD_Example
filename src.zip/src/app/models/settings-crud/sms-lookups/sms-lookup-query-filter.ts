export interface SmsLookupQueryFilter {
  IsActive?: boolean;
}