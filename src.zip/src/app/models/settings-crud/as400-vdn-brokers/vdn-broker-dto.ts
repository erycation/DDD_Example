export interface VdnBrokerDto {
    vdnBrokerId?: number;
    vdnNumber?: string | undefined;
    brokerCode?: string | undefined;
    brokerStatus?: string | undefined;
}