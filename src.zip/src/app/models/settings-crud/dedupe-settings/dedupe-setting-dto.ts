import { ContactStoreDto } from "../contact-stores/contact-store-dto";
import { LookupDto } from "../lookups/lookup-dto";
import { BaseDedupeSettingDto } from "./base-dedupe-setting-dto";

export interface DedupeSettingDto extends BaseDedupeSettingDto {    
    id?: number;
    isActive?: boolean | undefined;
    contactStore?: ContactStoreDto;
    activeType?: LookupDto;
    activeRisk?: LookupDto;
    inactiveType?: LookupDto;
    inactiveRisk?: LookupDto;
    leadType?: LookupDto;
    leadRisk?: LookupDto;
    outboundDedupeLevel?: LookupDto;
    inboundDedupeLevel?: LookupDto;
    addedDateTime?: Date;
    addedById?: number;
    updatedDateTime?: Date | undefined;
    updatedById?: number | undefined;
}