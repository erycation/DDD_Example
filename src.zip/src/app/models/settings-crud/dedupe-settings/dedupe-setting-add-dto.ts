import { BaseDedupeSettingDto } from "./base-dedupe-setting-dto";

export interface DedupeSettingAddDto extends BaseDedupeSettingDto {
    addedById?: number;
}