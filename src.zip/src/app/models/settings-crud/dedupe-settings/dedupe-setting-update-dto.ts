import { BaseDedupeSettingDto } from "./base-dedupe-setting-dto";

export interface DedupeSettingUpdateDto extends BaseDedupeSettingDto {
    isActive?: boolean | undefined;    
    updatedById?: number | undefined;
}