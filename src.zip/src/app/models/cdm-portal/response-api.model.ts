export interface ResponseApi<T> {
    message: string;
    data: T;
}