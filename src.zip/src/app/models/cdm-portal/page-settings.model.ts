export interface PageSettings {
    pageTitle: string;
    pageSizeOptions?: number[];
    pageSize?: number;
    viewOptions?: ViewOptions;
}

export interface ViewOptions {
    hasPagination?: boolean;
    isSearchable?: boolean;
    isSortable?: boolean;
    hasAdd?: boolean;
    labelAddNew?: string;
    actionsWidth?: number;
    hasView?: boolean;
    hasUpdate?: boolean;
    hasDelete?: boolean;
    hasFilter?: boolean;
}