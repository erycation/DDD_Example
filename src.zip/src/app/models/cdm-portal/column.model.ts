export interface Column {
    name: string;
    label: string;
    formatter: any;
    dataType?: string | null;
    width?: number | null;
}