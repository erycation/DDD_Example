export interface SmsSettingsDialogData {
  attempt: number;
  type: string;
  id?: number;
}