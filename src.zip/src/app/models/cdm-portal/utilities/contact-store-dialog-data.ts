import { ContactStoreDto } from "../../settings-crud/contact-stores/contact-store-dto";
import { LookupDto } from "../../settings-crud/lookups/lookup-dto";

export interface ContactStoreDialogData {
  initialValues: ContactStoreDto;
  lookupDictionary: Record<string, Array<LookupDto>>;
}