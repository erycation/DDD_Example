export interface UpdateData<T> {
  title: string;
  message: string;
  modelDto: T;
}