export interface SmsTableData{
  id: number;
  englishMessage: string;
  afrikaansMessage: string;
  isActive: boolean;
  attempt: number;
  smsType: string;
}