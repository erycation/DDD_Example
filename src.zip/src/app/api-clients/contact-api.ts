import { Injectable } from "@angular/core";
import { BaseApiClient } from "./base-api";
import { environment } from "../../environments/environment";
import { HttpHeaders } from "@angular/common/http";

@Injectable({
    providedIn: 'root'
})
export class ContactApiClient extends BaseApiClient {

    override API_URL = environment.api.url;

}