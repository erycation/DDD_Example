
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class BaseApiClient {
    public API_URL!: string;
    private employeeNumber!: string;

    public httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
        }),
    };

    constructor(private http: HttpClient) {
    }

    setBaseUrl(baseUrl: string) {
        this.API_URL = baseUrl;
    }

    get<T>(path: string): Observable<T> {
        const url = `${this.API_URL}${path}`;
        return this.http.get<T>(url, this.httpOptions);
    }

    post<T>(path: string, body: any): Observable<T> {
        const url = `${this.API_URL}${path}`;
        return this.http.post<T>(url, body, this.httpOptions);
    }

    put<T>(path: string, body: any): Observable<T> {
        const url = `${this.API_URL}${path}`;
        const headers = new HttpHeaders({
            'Content-Type': 'application/json',
            'Cache-Control': 'no-cache',
            'X-Employee-Number': this.employeeNumber || 'Test'
        })
        return this.http.put<T>(url, body, {headers});
    }

    delete<T>(path: string): Observable<T> {
        const url = `${this.API_URL}${path}`;
        return this.http.delete<T>(url, this.httpOptions);
    }

    patch<T>(path: string, body: any): Observable<T> {
        const url = `${this.API_URL}${path}`;
        return this.http.patch<T>(url, body, this.httpOptions);
    }

    options<T>(path: string): Observable<T> {
        const url = `${this.API_URL}${path}`;
        return this.http.options<T>(url, this.httpOptions);
    }
}
