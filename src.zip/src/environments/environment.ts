// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  api: {
    url: 'https://localhost:44332'
  },
  msalAuth: {
    auth: {
      clientId: 'b67a629a-c22a-4db8-98df-fa60e83921ec',
      authority: 'https://login.microsoftonline.com/8db3ceb8-7446-48bc-8bb4-97803c527a37',
      redirectUri: 'http://localhost:4200/',
    },
  },
  apiConfig: {
    scopes: ['user.read'],
    uri: 'https://graph.microsoft.com/v1.0/me?$select=displayName,mail,employeeId'
  },
  system: {
    systemId: 2
  },
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
