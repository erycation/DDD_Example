export const environment = {
  production: false,
  api: {
    url: 'http://10.200.103.136:30790'
  },
  msalAuth: {
    auth: {
      clientId: 'fcd8a2a8-5a2f-448c-b6c1-0f731711c34a',
      tenantId: '8db3ceb8-7446-48bc-8bb4-97803c527a37',
      authority: 'https://login.microsoftonline.com/8db3ceb8-7446-48bc-8bb4-97803c527a37',
      redirectUri: 'http://localhost:4200/',
    },
  },
  apiConfig: {
    scopes: ['user.read'],
    uri: 'https://graph.microsoft.com/v1.0/me?$select=displayName,mail,employeeId'
  },
  system: {
    systemId: 1
  },
};
