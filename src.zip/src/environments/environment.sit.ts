export const environment = {
  production: false,
  api: {
    url: 'http://10.200.113.77:30131'
  },
  msalAuth: {
    auth: {
      clientId: 'b67a629a-c22a-4db8-98df-fa60e83921ec',
      authority: 'https://login.microsoftonline.com/8db3ceb8-7446-48bc-8bb4-97803c527a37',
      redirectUri: 'https://user-management-sit.tihsa.co.za/',
    },
  },
  apiConfig: {
    scopes: ['user.read'],
    uri: 'https://graph.microsoft.com/v1.0/me?$select=displayName,mail,employeeId'
  },
  system: {
    systemId: 2
  },
};
